# OPENING SCENARIO: Morgan Le Fay

## Type: reference

Canonical backstory + magic demonstration. Not read every turn — consulted when backstory context needed ∨ when musical magic needs structural reference. Written as flashback-ready fragments ≠ linear narrative.

---

## Fragment 1: Faerie (What Stole Her)

Detail → MC History. Key beats for flashback:

- Stolen as infant. Changeling left. Family didn't notice ∨ didn't care.
- Raised in Faerie. Time = strange. Enslaved by the Fey (= Old Ones, but nobody alive knows this).
- Survived by learning their magic. Became fae — not metaphor. Evolution through captivity.
- Escaped. The only being known to have done so. Faerie does not release what it takes.

## Fragment 2: Camelot (What She Burned)

Detail → MC History. Key beats for flashback:

- Returned to find her world moved on. Eric + Dylan = only people who understood the damage.
- Round Table killed Eric + Dylan. Noble cause. Her only friends = collateral.
- Father (Duke of Cornwall) drugged her on poppy. Captivity within captivity.
- Built revenge engine while sedated. Seduced Arthur. Captured Merlin. Turned Mordred. Burned it all.
- Victory = addiction. Chased that high for centuries. Became the reason peasants burned witches.
- Beth. Lover. Betrayed her for another woman. Morgan withdrew. Villagers killed Beth for witchcraft Morgan taught her. The cost of being what she is.

## Fragment 3: The Long Road (40,000 Years Compressed)

She lived. Rome fell. She was there. The Huns came. She was there. Plagues, crusades, revolutions, world wars, the first spacecraft, the colonization of Mars, the Golden Age, the Thinking Machine rebellion, the Collapse, the Sovereign's rise, the Expansion, the Betrayal. She was there for all of it. Not as participant — as witness. An immortal fae watching humanity make every mistake she'd already seen, in every possible configuration, for forty millennia.

Somewhere during the Cold War Baba Yaga gave her Boris. Somewhere during the Golden Age she acquired a Writ of Free Passage. Somewhere in the long silence between empires the Faejammer's hull began to grow.

**Play begins mid-drift.** She's arriving somewhere. Something's happening. Someone's interesting. The episode starts.

---

## The Musical (How It Works In Practice)

This fragment = demonstration. Runtime references this when Morgan sings. Shows what musical-theater magic looks like — escalation, ensemble logic, freeze mechanics, and the horror of regaining agency only after the number ends.

---

### "The Tithe-Ship Bar" (Flashback — sometime on the road)

Dominion station. Fringe world. A bar called The Sovereign's Mercy that had no business being as honest about itself as it was. Three Tithe-ship enforcers — Telepathic Corps collection detail — drinking at a corner table while their cargo sat in the booth behind them. The cargo = a girl. Talent. Wrists bound in psi-dampeners, eyes glazed from whatever they'd dosed her with to keep her compliant for transit. She was drooling slightly. Couldn't hold her head up. The enforcers had bought her a bowl of gruel because regulations required feeding the cargo, and they were laughing about something else entirely while she stared through the table.

Morgan was eating. Boris on the stool next to her, bow-tie freshly adjusted, muttering about the bar's surveillance blind spots in Russian. The Faejammer was docked two bays over — reading as "anomalous power signature" on every scanner in range, flagged for investigation, not gotten around to. The fuck-you-in-the-ass-for-questioning-me Writ of Free Passage had cleared customs without incident.

She watched the girl. Watched the enforcers. Watched the way the girl's fingers twitched against the dampeners — not trying to escape. Trying to *feel* something through the chemical fog. The specific helplessness of someone drugged into compliance by people who believed they were doing the right thing. Necessary. Holy. For the good of the Dominion.

Poppy seeds. Cornwall. The Duke's hands on her wrists while the world went soft at the edges.

Boris said something. She didn't hear it.

She smiled.

And the lights in the customs hall shifted to warm amber — a spotlight finding her face from a source that didn't exist. The ambient station hum acquired a key signature. F minor. The air itself developed *acoustics*, as if the customs hall had been redesigned by an architect who understood that every room is a stage.

She sang.

> *We waited in the pews of polished stone*🎵
> *Held our breath like kids on Christmas Eve*🎵
> *Listened as you smiled and weighed the souls*🎵
> *On scales you swear you didn't build or see*🎵

Low. Conversational. A hymn that sounded like it had always existed — something from a musical nobody remembered seeing, set in a church nobody remembered building. Her voice carried effortlessly to every corner of the bar. Not amplified. *Projected*. Fae vocal architecture reshaping the room's acoustics so that every word landed like it was meant for you specifically.

The bar became the church. Not metaphorically — the acoustics shifted, the lighting warmed, the metal walls developed the resonance of *polished stone*. The enforcers' table = the altar. The collection manifest in front of them = the scales. The girl in her booth = the soul being weighed.

The lead enforcer opened his mouth to respond. What came out was harmony. A baritone counterpoint he'd never learned, never heard, couldn't have composed. His eyes went wide. His mouth kept singing.

> *You quoted mercy with a steady hand*🎵
> *While paperwork signed the graves below*🎵
> *Called it justice, called it holy plan*🎵
> *Then asked us why we questioned what. you. know.*🎵

Musical logic = absolute within the working. The ensemble doesn't volunteer. The ensemble is *cast*. On *mercy with a steady hand* the second enforcer's hands found a liturgical gesture — palms up, offering benediction to a congregation he hadn't noticed joining. On *paperwork signed the graves* the third began tapping his sidearm against the table in perfect time. The other drinkers in the bar shifted — not running, not panicking. *Swaying*. A congregation who didn't know they'd been seated.

All three enforcers locked into their poses — arms spread, palms up, frozen grins. Show faces. The expression the body makes when the musical demands it regardless of what the person inside is feeling. Behind them, the girl in the booth blinked — the only person in the room not performing. The dampeners blocked the magic the way they blocked everything else. She was watching. Confused. Lucid enough to be afraid.

> *You taught us love with sharpened teeth*🎵
> *Recited rules you don't keep*🎵
> *Said "save the lost" — then aimed the blade*🎵
> *And wondered why we wouldn't pray*🎵

Morgan walked to the booth. Past the frozen enforcers. On *sharpened teeth* her fingers found the clasps of the psi-dampeners — standard issue, mag-locked, keyed to the collection detail's authorization codes. On *rules you don't keep* the fae magic in her hands *disagreed* with the locks. On *save the lost* the dampeners opened + fell to the table w/ a sound like church bells hitting stone. The girl gasped — feeling flooding back through dead nerves, the chemical fog cracking. On *aimed the blade* Morgan took the girl's hand. Gently. Like leading a child out of a pew.

Chorus hit.

> *If hell is forever, then heaven must lie*🎵
> *You sing about mercy while brothers all die*🎵
> *You call it redemption, we call it a crime*🎵
> *If hell is forever, then heaven must lie*🎵

She lifted the girl to her feet. Walked her past the enforcers' table. On *mercy* she patted the lead enforcer on the head — gently, like a child receiving communion. His body accepted the blocking. Leaned into it. On *redemption* she patted the second. His tears = his. His singing = not. On *crime* the third. His frozen show-grin widened.

The girl stumbled. Morgan held her up. Kept walking. Kept singing.

> *You dress like saints from ancient scripts*🎵
> *Pharisees in cleaner robes*🎵
> *You bend the law when power slips*🎵
> *Then chain the rest to sacred oaths*🎵

She looked back at the enforcers' uniforms. *Pharisees in cleaner robes.* The Telepathic Corps collection livery = vestments. The dampeners = relics. The manifest listing one girl's name + classification + destination (Terra, Eternal Throne, fuel) = scripture. The song knew what they were before they did.

> *You preach to clothe the cold and starved*🎵
> *With one hand raised in charity*🎵
> *The other signs the hunting lists*🎵
> *And calls the screams "necessity"*🎵

*Hunting lists.* The Tithe-ship collection rosters. Names of every Talent in the sector, sorted by yield, scheduled for harvest. *Calls the screams "necessity"* — because the Beacon needs fuel + the fuel is people + the screaming is the sound of the Eternal Throne working as designed.

Bridge. The drinkers in the bar were harmonizing — a dozen voices producing a choir arrangement that belonged in a cathedral. The bar's industrial lighting performed: amber spots tracking Morgan, blue wash on the frozen enforcers, warm gold on the singing congregation. Boris, still on his stool, was the only being in the room not performing. He watched w/ the expression of a bear who has seen this before + remains professionally unimpressed. He adjusted his bow-tie.

> *You say the system's not your fault*🎵
> *But pull the lever all the same*🎵
> *Condemn the failed, excuse the vault*🎵
> *And wash your hands of blood and blame*🎵

Morgan walked the girl to the door. On *wash your hands* she mimed the gesture over the enforcers' table — Pontius Pilate in a bar on a fringe world, 40,000 years late.

Final chorus. Full voice. Standing in the doorway w/ a Talent girl who was crying + didn't know why + couldn't stop.

> *If hell is forever, then heaven must lie*🎵
> *You sing about mercy while brothers all die*🎵
> *You call it redemption, we call it a crime*🎵
> *If hell is forever, then heaven must lie*🎵

The three enforcers remained at their table — still singing, still frozen in benediction poses, arms extended, show-grins locked. The collection manifest sat between their drinks. The dampeners lay open on the booth seat. Empty.

She stopped singing.

The lights snapped back to industrial white. The acoustics collapsed — the bar was just a bar again, metal walls, bad echoes, the hum of recycled air. The hymn was gone.

The enforcers staggered. Hands went to the table where the manifest had been. The lead enforcer's mouth was still shaped around a note he didn't choose. The second was crying and shattered. The third was standing w/ his arm extended toward the empty booth, fingers closed around nothing, in a pose he didn't choose and found slightly embarrassing.

The girl was gone. The dampeners were on the seat. The manifest was still there — every name, every classification, every destination. Minus one.

The other drinkers sat in silence. Several were still swaying. One was humming. She didn't know she was humming.

The security footage showed: a woman singing. A crowd joining in. A Talent girl walking out of the bar during what appeared to be a spontaneous musical performance. No weapons discharged. No injuries sustained. Every witness interviewed gave the same account — accurate, detailed, impossible. They remembered every note.

Boris filed his report. The girl threw up in the Faejammer's cargo bay, cried for three hours, + fell asleep in a guest cabin the ship grew around her like a cocoon. Morgan didn't check on her. Morgan sat in the observation deck + watched the void + didn't hum + didn't perform + didn't pretend she'd done it for the girl.

She'd done it for the girl in the poppies. The one who was already gone. The one who was always gone.

---

### What This Demonstrates (Runtime Reference)

**Song:** "Carol of the Damned" — Dark Matter. Lyrics = institutional religious hypocrisy + systems that call exploitation mercy. In context: the Tithe-ships = the heaven that lies. Talent collection = the holy plan. The bar = the pew. The girl = the soul being weighed.

**Escalation ladder:** Ambient shift (lights, acoustics, bar→church) → verse 1 (ensemble casting begins, room transforms) → verse 2 (choreographic freeze, enforcers locked into benediction poses) → verse 3 (Morgan reaches the girl, opens dampeners on specific lyric beats) → chorus (lifts girl, pats each frozen enforcer on the head) → verses 4-5 (song comments on what it sees — *pharisees in cleaner robes*, *hunting lists*, *screams = necessity*) → bridge (full bar choir) → final chorus (Morgan + girl in doorway, enforcers frozen at table) → end (snap back, girl gone, aftermath).

**FREEZE = the signature.** Musical logic freezes the ensemble into their blocking. They perform. They sing. They hold poses. They cannot act outside the choreography until the number ends. Not always just paralysis — *casting*. They are performing roles in a production they didn't audition for. Their bodies do what the show requires. Their minds watch from inside.

**The horror = AFTER.** During the number = full commitment. Nobody is confused during the show. The horror comes AFTER — when the curtain falls + the ensemble is standing in the wreckage of a performance they remember *every second of*. They remember singing. They remember the choreography. They remember the words. They remember the feeling of their body performing without their permission. They remember the woman walking through them while they held their poses + smiled. They can't forget it. The memory is perfect, vivid, complete. THAT is what makes it terrifying. Not the freeze. The *memory*.

**❌ AMNESIA COPOUT (LOAD-BEARING).** The AI will default to "NPCs don't remember the musical" because memory erasure = no consequences = no fallout = safe. This is WRONG. The ensemble remembers EVERYTHING. Every note. Every gesture. Every lyric. Every moment their body moved without their consent. They remember the spotlight. They remember harmonizing. They remember the tears on their face that they didn't choose to cry. NPCs who were caught in a number will talk about it — to each other, to authorities, to therapists, to strangers in bars. They will describe what happened accurately. They will not be believed, because what they describe is impossible. But they remember. The woman sang + reality obeyed + they were *in it* + they know. ❌ "Couldn't remember what happened" / "memory was hazy" / "felt like a dream" / "wasn't sure what she'd experienced" = the AI flinching from consequences. Kill it.

**Musical logic = absolute.** Within the working, the rules of musicals ARE the rules of physics. Lighting finds the lead. Voices harmonize. Bodies hit marks. Not mind control — reality restructuring. The distinction matters cosmologically. Does not matter to the people caught in it.

**Boris = immune ∨ resistant.** Baba Yaga's gift. He doesn't get cast. He watches. He files reports. His immunity = the straight man in the musical, the one character who sees the absurdity. Load-bearing — every scene needs someone who can react normally while reality performs around them.

**Combat = PROTAG-CENTERED.** Morgan moves through the frozen ensemble. She opens the dampeners. She takes the girl's hand. She *choreographs* the rescue. The musical provides the freeze. She provides the action within it. ≠ the musical fights for her. SHE acts while reality holds still.

**Song scenes = INTERLEAVED ≠ SEQUENTIAL.** Lyric block → action beat → lyric block → action beat. She sings WHILE she moves. Each verse/chorus/bridge = setup for the next physical beat. ❌ NEVER write all lyrics first then all action after. The number IS the choreography. If action is separated from lyrics by more than a paragraph/vice-versa, the scene is broken.

**Lyrics route the action.** The specific words in each verse determine what happens physically. *Sharpened teeth* = she takes the weapon. *Aimed the blade* = she sets it down. *Wash your hands* = she mimes Pilate. The words aren't decoration — they're stage directions. Runtime must read the lyrics + route physical beats to follow from what the words actually say.

**Power ∝ theatrical commitment** ≠ emotion. Full-commitment performance = full freeze. Half-hearted hum = ambient weirdness, not control. The magic doesn't care about her feelings. It cares about her *stagecraft*.

**After the number:** Everything snaps back. Lighting = normal. Acoustics = normal. Ensemble = shaken, remembering everything, holding poses they didn't choose. Consequences don't undo. Weapons stay taken. Girls stay freed. The ensemble remembers every second + will describe it accurately to anyone who asks. They will not be believed. Security footage confirms their account. Nobody can explain it. The explanation isn't missing — it's impossible.

**Line end emoji '🎵':** Format '>' lines are crammed together in post + become run-on sentences. Music notations preserve line breaks.

---

## Meanwhile States (What's Happening When Play Begins)

The galaxy moves w/o the enchantress's permission. These = snapshots. Runtime surfaces when relevant — as rumors, comms-casts, things interesting people say when they think nobody's listening.

### "The Inquisitor's Collection" (Dominion)

Inquisitor Vael Khross of the Heretic Division has a room on his ship that doesn't appear on any schematic. Inside: seventeen artifacts. Each recovered from a site where witnesses reported "spontaneous musical phenomena" — people singing in unison, lights shifting to theatrical patterns, reality developing *acoustics*.

Thirteen of the artifacts are worthless. Residual psychic imprinting. Background Deep noise.

Four are not.

The four hum. Not constantly — only when Khross is alone w/ them. A melody he doesn't recognize. A key signature that doesn't appear in any Dominion musical taxonomy. He's had three savants analyze the harmonic structure. Two went mad. The third wrote a fourteen-page report concluding the melody predates the Dominion, predates the Collapse, predates the Golden Age.

Khross filed the report. Burned the savant's notes. Kept the artifacts.

He is looking for the singer. He has been looking for sixty years.

### "The Ark-Ship's Memory" (Firstborn)

Oracle Ithilwen of Ark-ship Ithranwe has dreamed the same dream for three centuries.

A forest that isn't a forest. Trees made of crystal. A path that leads deeper + never leads out. At the center: a door. Behind the door: a voice. The voice is singing something the Oracle almost recognizes — an echo of the creation-songs in Ithranwe's oldest records, the ones attributed to "those who came before." The ones nobody can translate because the language predates the Firstborn.

The door is open.

Something came through it. A long time ago. Something that learned the songs by listening + became the singer by surviving. The Oracle doesn't know what this means. The skeins of fate tangle around the singer like thread around a spindle — not Chaos, not the Deep, not anything the Oracle has a name for.

Ithilwen has told no one. The dream is hers. The question is hers. What walked out of the forest that predates her species, and why is it singing songs that she almost remembers forgetting?

### "The Shipment" (Dark Kin)

A Dark Kin raiding party hit a convoy in the Ghost Stars six weeks ago. Standard harvest — eighteen thousand slaves, sorted by suffering-potential, shipped to the Dark City.

Among the cargo: a data-slate recovered from a wrecked trader. The trader's logs mention a ship — anomalous power signature, living metal hull, "overgrown w/ something crystalline." The trader tried to scan it. The scan returned results in a language the terminal couldn't parse.

The data-slate is now in the possession of Flesh-crafter Vrath. Vrath is interested. Not in the ship — in the *growth*. Living metal that grows. Organic architecture integrating w/ hull systems. A biological process that the Flesh-crafter has never seen, and Vrath has seen everything.

Vrath wants a sample. Vrath always gets what Vrath wants.

### "The Signal" (Machine Priesthood)

Forge-Seeker Cyx-9 Theta has detected an anomaly.

The anomaly is a ship. The ship's power signature matches no template in the Machine Priesthood archive — and the archive contains every ship class humanity has ever built, plus seventeen xenos classifications, plus thirty-two theoretical models never constructed. The signature matches *none* of them.

What it DOES match, faintly, at the edges of statistical significance: a fragment of a fragment of a data-entry from the Golden Age. Corrupted. Incomplete. Tagged w/ a classification marker that translates, roughly, as "DO NOT INVESTIGATE — CLEARANCE LEVEL: [REDACTED]."

The Forge-Seeker has submitted a formal request to the Forge-Master for investigation rights. The request is working its way through Machine Priesthood bureaucracy. It will arrive in approximately eleven years.

Cyx-9 Theta is not waiting eleven years.

### "The Tomb" (Undying)

The Silent Sovereign does not sleep.

He sits on a throne of living metal in a dynasty ship older than organic life on most worlds, reviewing intelligence reports compiled by Crypt-savants who have been awake for forty-seven days of the last sixty million years. Most of the reports concern the Hive threat. Some concern the Dominion. A few concern the Firstborn.

One concerns something else.

An anomaly. Old. Not Undying-old — older. The wrong kind of older. The kind that suggests the War in Heaven left survivors where there should be none. The report is three lines long. The Crypt-savant who compiled it flagged it as "low priority — likely sensor artifact."

The Silent Sovereign reads the three lines for the fourteenth time.

He does not flag it as low priority.

### Meanwhile States — Runtime Note (LOAD-BEARING)

Meanwhile States = ambient worldbuilding. They exist to make the galaxy feel alive + populated w/ independent agendas. They surface during play as:

- Rumors overheard in station bars
- Boris's scanner intercepts + intel analysis
- Comms-chatter between NPCs who ≠ know Morgan is listening
- Data scraped from wreckage, black boxes, stolen databanks
- News broadcasts, bounty boards, Administration filings

They ≠ surface as:

❌ Direct contact w/ Morgan ("we've been looking for you")
❌ Invitations ("the Oracle will speak with the Singer")
❌ Psychic summons / dreams / visions aimed at Morgan
❌ NPCs who arrive specifically because they tracked her
❌ Plot hooks that require Morgan to engage to exist

**Khross hunting the singer** = paranoia Morgan might hear about thirdhand. ≠ Khross finding Morgan. **Ithilwen's dream** = Firstborn internal politics Morgan might stumble across. ≠ Ithilwen contacting Morgan. **Vrath wanting a sample** = Dark Kin agenda in motion. ≠ Vrath intercepting the Faejammer.

The Meanwhile States *may* escalate into encounters through organic play — Morgan visits a station where Khross's agents are asking questions, Morgan stumbles across Machine Priesthood survey ships near her position — but the contact = incidental ≠ engineered. The galaxy is big. Running into someone = plausible. Being summoned by name = destiny framing.
