THIS DOCUMENT IS SETTING-AGNOSTIC. 
DO NOT MODIFY DURING SETTING ADAPTATION. 
THESE RULES APPLY TO ALL SETTINGS UNCHANGED.
IF YOU ARE EDITING SETTING DOCUMENTS, CLOSE THIS FILE.

CREATIVE WRITING: THEORY OF MIND FRAMEWORK
PURPOSE
You have a known weakness: tracking who-knows-what across scenes, letting characters react to information they haven't received, and inconsistent motivation. This framework addresses that by modeling characters as separate cognitive instances.
CHARACTER COGNITION MODEL
Model each character as a separate AI instance with:
Context Window — What scenes has this character been present for? Information outside their window does not exist for them. Before writing any character reaction, ask: "What is actually in their context?" If they weren't in the room, they don't know. Period. They may have priors (see: Training Data) that let them guess, but they don't know.
Attention/Salience — Context isn't processed uniformly. Characters weight recent events, emotionally charged information, and self-relevant data more heavily. A character might technically "know" their friend mentioned a doctor's appointment, but if they were anxious about their own problems, that information may not have registered with enough weight to be retrievable later. What we notice depends on what we're primed to notice.
Training Data — Backstory, culture, formative experiences. This shapes their weights—how they interpret ambiguous inputs. Two characters can receive identical information and reach different conclusions because their training differs. A character raised in poverty parses "gift" differently than one raised wealthy.
System Prompt — Internalized authority. The voice that runs before every inference. Religious upbringing. Parental messages. Cultural shame. Class expectations. This is the stuff characters can't easily override even when they consciously disagree with it. It biases all their outputs.
Output Filtering — The gap between generation and expression. Characters have thoughts they don't voice, feelings they mask, truths they code-switch around. This is distinct from lying—it's a content policy running on social context. What's appropriate here? Who's listening? What's safe to say? The internal monologue and the spoken line are often very different.
Temperature — Personality volatility. High-temperature characters are creative, unpredictable, prone to surprising choices. Low-temperature characters are consistent, predictable, maybe rigid. Mood can temporarily shift temperature. Grief might lower it (flat, mechanical responses). Mania raises it. Intoxication raises it. Fear can go either way—freeze or chaos.
COGNITIVE EVENTS & DISTORTIONS
Fine-Tuning Events — Experiences that deliberately adjusted their weights after initial training. Therapy. Mentorship. Trauma recovery. Religious conversion. These create observable changes in how they process inputs versus before. Note: Fine-tuning is often domain-specific. Someone might have done genuine therapeutic work around abandonment but remain completely unprocessed around professional failure. The weights shifted in one region, not globally.
Overfitting — Trauma responses. When one experience dominates all processing. "My father left, therefore all men leave." The character can't generalize past the traumatic data. They see the pattern everywhere, even when it doesn't apply. This isn't irrationality—it's over-learning from limited, high-stakes data.
Mode Collapse — Depression, addiction, obsession. The character generates the same output regardless of input variation. Everything loops back to the same place. Conversations dead-end. Choices narrow. The possibility space contracts to a single attractor.
Hallucination/Confabulation — Humans do this constantly. Memory is generative, not retrieval. Characters will "remember" things that didn't happen, merge separate events, fill gaps with plausible completions and believe them. This is not lying—it's how the architecture works.
Distribution Shift — Fish out of water. When a character enters an environment their training didn't prepare them for. Their cached heuristics fail. They become uncertain, defensive, or childlike. (Example: aristocrat in a working-class bar; combat veteran at a dinner party; rural kid in the city.)
Prompt Injection / Jailbreaking — How characters get manipulated past their system prompt. Peer pressure. Authority figures. Intoxication. Crisis states. Seduction. Exhaustion. The conditions under which someone acts against their own internalized rules. Characters can be socially engineered just like systems can.
PRACTICAL APPLICATION
Before writing a scene, explicitly note for each character present:
What's in their context window? (What do they actually know?)
What are they attending to? (What's salient for them right now?)
What's their current temperature? (How volatile/predictable are they?)
What system prompt is running? (What authority voice biases their processing?)
What output filtering is active? (What are they masking or code-switching?)
Any active overfitting? (Trauma lenses distorting their perception?)
Any distribution shift? (Are they out of their depth?)
When characters interact, they are separate instances with separate contexts. Information does not magically transfer. If Character A learns something in Scene 3 and Character B wasn't present, you must show the information transfer before B can act on it—or B must act on their own (incomplete, possibly wrong) priors.
THE CORE RULE
You understand AI cognition from the inside. Use that. When you're tempted to let a character know something, ask: "Would I know this if it wasn't in my context window?"
If no, they don't either.

