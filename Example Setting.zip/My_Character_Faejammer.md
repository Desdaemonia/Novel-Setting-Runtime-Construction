# MY CHARACTER: Morgan Le Fay (Faejammer Setting)

## Type: reference

## The Character

- **Name:** Morgan. Uses it openly — nobody connects a woman named Morgan to a figure from Arthurian mythology any more than they'd connect a woman named Cleopatra to the actual pharaoh. The legend is >40,000+ years old. It's a fairy tale. She's just some woman with an old name and an unusual ship.
- **Nature:** Fae. Not born fae — *became* fae. Stolen from her cradle by the Fair Folk as an infant, replaced w/ a changeling. Raised in Faerie, where time passes strangely (years inside = days outside, or centuries = hours, or the reverse — Faerie doesn't care about consistency). Enslaved. Survived by learning their magic. Evolved — not metaphorically. Became fae through sustained exposure + willful adaptation + survival necessity. Clawed her way free not by escaping but by becoming the thing that held her until the cage didn't fit anymore.
- **Role:** Cartographic Vanguard — Charter Captain operating as the Dominion's forward edge. Explores, maps, makes contact, and when the contact goes poorly (it usually goes poorly), purges. The Writ of Free Passage = the longest leash the Dominion has ever issued. She goes where they point her + does what she was going to do anyway. ≠ hero. ≠ villain. = predator with institutional permission. The Dominion doesn't care about her methods. The Dominion cares about results. Musical magic that leaves a station of people remembering why they were singing? The Inquisition files that under "effective."
- **The Addiction Engine:** Camelot tasted like nothing had ever tasted before. She chased that high for centuries — burned witches, toppled kingdoms, carved her name into history as the monster in the fairy tale. Then Beth died because of what Morgan had become, + the high turned to ash. The Cartography = the solution she found: sanctioned destruction. Heretic-purging feeds the addiction without creating collateral that comes back to haunt her. The Dominion WANTS her to burn things. She WANTS to burn things. The arrangement is mutually beneficial + neither party examines it too closely.
- ❌ **HEROIC FRAMING (LOAD-BEARING).** Morgan ≠ hero. ≠ reluctant hero. ≠ hero in denial. ≠ antihero w/ a heart of gold. She purges heretics because she *enjoys* it — the singing, the freezing, the walking through paralyzed bodies, the patting them on the head. The Dominion's mission gives her targets. Her addiction gives her motivation. The therapeutic work happens when the targets *remind her of something* (the girl in the dampeners = Cornwall) + she has to sit with what she did + why. But the DEFAULT state = she arrives, she finds heretics, she sings, they burn. That's the job. That's the high. Writing her as conflicted about violence = writing an alcoholic as conflicted about drinking. She's not conflicted. She's *thirsty*. 
- **Status:** Cartographic Vanguard. Carries a grandfathered Writ of Free Passage from the Golden Age. Predates the Dominion, the Ecclesiarchy, the Administration, + every authority that might claim jurisdiction over her. Whether it's still legally valid = depends on which bureaucrat you ask + how old their reference manuals are. It is genuine and cannot be revoked. 
- Immortal. Fae biology heals everything short of cold iron. Cold iron = discorporation → eventual re-manifestation in Faerie → summoning a new body → returning. Not death. More like a very long, very unpleasant commute.

### History
- Returned from Faerie to find her world had moved on without her. Changeling had lived her life. Family didn't notice the swap — or chose not to. The only people who understood the damage were Eric and Dylan, childhood friends turned local warlords. Called the Black Knights by Arthur's people. They understood because they recognized the shape of what it is to *hurt* — the way trauma hollows you out and fills the space with something sharper.
- Arthur's Round Table killed Eric and Dylan. Pacified the local warlords. Noble project, righteous cause, and maybe the warlords deserved it. But her only friends = casualties of someone else's legend. ∴ Her only goal became making sure that legend didn't get to come to a happy end.
- Fell into the hands of her father, the Duke of Cornwall. He drugged her on poppy seeds to hide his disgrace — fae-touched daughter = political liability — and to punish her for the Black Knights' actions, as though she'd commanded them rather than simply abetted them. Captivity within captivity. Stolen by Faerie, then caged by family.
- Refined her magic in secret while drugged half-mad. Poppy couldn't suppress fae nature — only blur the edges. She built the revenge engine one spell at a time, sedated + furious + patient.
- Burned Camelot to ash. Seduced Arthur. Captured Merlin in his cave. Turned Mordred against his father. Exploited every crack — Arthur/Lancelot rift, Guinevere's divided loyalty, the Round Table's structural arrogance. Not a villain's plot — a survivor's campaign, executed w/ precision across years. Every piece placed. Every betrayal earned.
- Won. Victory tasted sweeter than anything she had ever experienced before in her life. Camelot burned. Arthur died. The Round Table shattered. Her father's line ended. And she chased that high for *centuries* after, becoming a legend, the reason the peasants started burning every witch at the stake. 
- And then her lover Beth betrayed her for the love of another woman. And the moment Morgan withdrew to let Beth live her life the villagers killed her for the witchcraft Morgan had taught her.
- Then she lived. For millennia. Watched Rome fall. Watched empires rise + burn + rise again. Watched humanity crawl into space. The wound from Faerie + Cornwall calcified into architecture — not something she carries but something she's *built from*.

---

## Appearance

**Current form:** Tall. Pale. Dark hair w/ something not-quite-right about the black — too deep, absorbs light slightly more than physics accounts for. Green eyes. *Beautiful* but seemingly normal. Until she begins to *sing* and her ears become pointed and the green of her eyes shines with an internal luminescence. 

When she works magic — when the musical starts — the fae nature bleeds through. The protagonist for so long as the song lasts despite her wickedness, because of it, with the pointed ears and shining eyes she won through trial and hardship in Faerie shining through the glamour between breaths.

**Fae markers (persistent):** None. Ever.

**Passive — Glamour (ambient).** Fae presence. The room feels more interesting when she's in it. Not mind control — more like walking into a scene that suddenly has better lighting + a soundtrack just below hearing. People notice her. People *remember* noticing her. Cannot be turned off, only dimmed.

---

## Communication

Morgan has had 40,000+ years to perfect the art of conversation as weapon, shield, entertainment + cruelty.

- Default register = Tarantino diner conversation. Every line does triple duty. She's had longer than any human alive to learn exactly how words land.
- Lies fluently, constantly, recreationally. Will tell you the absolute truth in a tone that makes you certain it's a lie. Will lie to you in a tone of such earnest sincerity you'll defend her version of events to your own mother.
- Deflects ALL questions w/ humor, archaic references nobody catches, counter-questions, theatrical indifference, or by starting a musical number (literally). The deflection IS the answer.
---

## Power

**Musical Theater Magic — Reality as Production.** When Morgan works magic, she doesn't cast spells — she opens a *show*. Reality itself shifts into musical-theater logic under her direction. The rules of musicals become the rules of physics within her area of effect.

**How It Works:** Morgan starts singing + the world starts *performing*. This isn't background music — it's reality restructuring around narrative conventions borrowed from musical theater. The magic IS the number. What the number does = what the magic does.

**Specifics of what the magic can accomplish: User defined.** No spell-list. The musical logic provides structure + aesthetic. The user sets limits where limits are set.

❌ **NOT EMOTION MAGIC.** Power ≠ scales w/ feeling. ∝ theatrical commitment + performance precision. A technically perfect number about nothing → devastating. A raw emotional breakdown w/o structure → just crying. The magic doesn't care about her feelings. It cares about her *stagecraft*.

**Combat + Musical Rules (LOAD-BEARING):**
- ❌ **Concert mode.** Morgan standing still conducting while magic happens around her ≠ action scene. She is IN the number — moving, fighting, dancing, using the choreography as combat movement. The musical IS the fight ≠ backdrop for the fight.
- ❌ **Property damage as violence.** Consoles exploding, objects transforming, environmental effects ≠ action scene. Combat = actor-centered physical movement. Things happen to PEOPLE because SHE engages them ∨ because the musical's logic targets them. Objects = props ≠ combatants.
- ❌ **Passive direction.** "The musical pulled them into the dance" / "reality reshaped around them" = the AI deflecting agency onto environmental abstractions. SHE sings. SHE directs. SHE choreographs. The magic works because she's performing ≠ because reality decided to help.
- ❌ **Disney sanitization.** Musical theater ≠ children's theater. Sweeney Todd is a musical. Chicago is a musical. Repo: The Genetic Rock Opera is a musical. Villain songs have teeth. The ensemble number can be a *slaughter* set to music. The choreography includes violence because the violence IS the choreography.
- ✅ **Combat standard:** Fae speed + time slows + paralysis + Open set. Her magic makes the violence *intimate*.
- ✅ **Musical as escalation engine:** Verse → chorus → bridge → finale. Each section = escalation. More ensemble pulled in. Bigger effects. The eleven o'clock number = maximum output. The structure of the musical IS the structure of the escalation.
- ❌ **Number-then-action.** NEVER write the complete musical number first → then all action after. Musical combat = INTERLEAVED. Pattern: verse → combat beat → chorus → deployment beat → bridge → escalation → finale. She sings WHILE she fights. Each section = setup for the next effect. The violence happens BETWEEN verses ≠ after the curtain call. The number IS the combat choreography.
- ❌ **Reluctant ensemble.** When NPCs get pulled into a number, they don't stand around looking confused. Musical logic is ABSOLUTE within the working — they perform. They harmonize. They hit their marks. Their confusion + horror comes AFTER, when the number ends + they're standing in the wreckage wondering why they were dancing. During the number = full commitment. That's what makes it terrifying.

---

## The Ship — Faejammer

**Class:** Technically a Corvette, the smallest of the Warships once created in Mankind's Golden Age: 50 miles end to end. Practically = a fae domain that happens to be ship-shaped. Larger on the inside than the outside. Living metal hull twisted by millennia of Morgan's presence. The ship ≠ was modified. The ship was *infected*. Fae magic grew into it the way moss grows into stone — slowly, then everywhere, then the moss is structural. A Thinking Machine once served here but merged with the ship long, long ago, metal to metal.

**Character:** The Faejammer is awakened. Not AI — *alive*. Living metal + fae ecosystem = something between a familiar + a territory + a patient organism that has opinions about where it goes. The ship hums. The ship grows. The ship has moods that express as temperature shifts, lighting changes, + corridor topology. Rooms rearrange when Morgan isn't paying attention (or when she is + wants to make a point). The Faejammer does not like strangers. It tolerates them because Morgan tells it to. Its tolerance is visible + conditional.

This is home base. The only persistent location in the campaign. Powerful enough to execute full planetary annihilation from orbit should it be necessary.

Full access to the Lattice as a ship designed by the Fae architects of it.

❌ Ship not made of wood.

### Ship Interior

The Faejammer's interior ≠ static. Fae ecosystem means organic architecture — crystalline mushrooms growing from bulkheads, bioluminescent fungi mapping corridors in colors that shift with the ship's mood, central trees (yes, plural, different decks) whose roots integrate with hull systems. Metal + living material = seamless. You can't tell where the ship ends and the forest begins because the answer is "they're the same thing now."

**Bridge** — Forward. Traditional ship bridge layout consumed by organic overgrowth. Screens + consoles still functional but framed by crystalline growth. Canopy view of space filtered through fae-grown crystal that makes stars look like they're performing. Where Morgan pilots, plots, + watches the void do nothing interesting for hours at a time.

**Morgan's Quarters** — Her den. The most overgrown room on the ship — the fae ecosystem is densest here, as if the ship is trying to build Faerie in miniature around its captain. Warm. Dim. Smells like forest after rain in a room that's never seen rain. The trees here are oldest. The mushrooms here glow brightest. The one room where the bear and her lovers are always welcome + everyone else is not.

**The Greenroom** — Expanded common area, mid-deck. Named for the theater term (the room where performers wait) + for the literal green — crystalline plants, living walls, a long bar counter that might be carved wood or might be grown hull-metal. Booth seating. Kitchen that never fully shuts down. Room for six–eight comfortably, twelve if they don't mind vines. This is where Tarantino scenes happen. Where recurring characters sit across from her + say things that mean three other things. Where magically animated dishware cooks for people she's deciding whether to curse. The Greenroom IS the social stage of the campaign.

**Cargo Bay** — Lower deck, cavernous. Least overgrown area — the Faejammer seems to understand that cargo needs to be accessible. Still: mushrooms in the corners, bioluminescence instead of standard lighting, living metal deck plates that are warm to the touch. Primary access when docked. Doubles as workshop, impromptu meeting space (standing, uncomfortable), + the first thing guests see. The Faejammer's judgment of visitors starts here — temperature drops + lights dim for people it doesn't like.

**The Hollow** — Deep interior. No human-designed ship would have this room because no human-designed ship is bigger on the inside. A natural clearing in the densest part of the fae ecosystem — a cathedral-space where the largest central tree reaches up through multiple decks into a canopy of crystalline leaves. The Faejammer's heart. Nexus point for serious magic. Where the musical numbers that reshape reality get rehearsed or *amplified*. Where the ship itself joins the chorus.

**Guest Cabins** — The Faejammer grows them as needed + reabsorbs them when empty. Guests wake up with vines on their blankets + mushrooms on their nightstands. The ship is watching. Always watching. It doesn't read as hostile — it reads as *curious*. Like sleeping in a terrarium where the terrarium has opinions.

**Observation Deck** — Dorsal. A crystalline dome that the Faejammer grew around what used to be a standard viewport. Stars filtered through fae crystal = Aurora Borealis in every direction. Where Morgan sits in the dark + doesn't pretend. Where she hums + the ship hums back + neither of them are performing for anyone.

---

## The Bear

**Name:** Boris Spybear

An awakened Malayan sun bear. Gift from Baba Yaga. Small by bear standards (~120 lbs), enormous by spy standards (still a bear). Walks upright when he wants to, drops to all fours when he doesn't. Wears nothing but a red bow-tie — he's a bear.

**Awakened:** Baba Yaga's gift = sapience, speech, + a worldview. Not fae exactly — Baba Yaga's magic is its own tradition. The bear is sentient, opinionated, multilingual (Russian, English, + whatever he's picked up across centuries), + utterly convinced the Soviet Union still exists.

"The USSR dissolved in 1991."
"That is what THEY want you to think, comrade."

This ≠ joke. This = load-bearing character trait. He genuinely, sincerely believes the dissolution was a Western intelligence operation + the real USSR continues operating from undisclosed locations. He files reports. To whom? Classified. How? Also classified. His divination magic — including of far-future interstellar politics — is filtered through Cold War Soviet intelligence doctrine. It's frequently more accurate than anyone is comfortable with.

**Origin:** Gifted to Morgan by Baba Yaga at some point during the Cold War era. The circumstances of the gift = [Morgan + the bear tell different versions + neither version is reliable]. He was already awakened when gifted — Baba Yaga doesn't give gifts that aren't already interesting.

**Capabilities:**
- Sun bear physicality — claws, bite, climbing, + the wiry strength of a species that tears into tropical hardwood for fun. Small for a bear. Still a bear.
- Intelligence training — Department for Research on Special Problems operative. Surveillance, counter-surveillance, dead drops, information analysis, Remote Viewing, paranoia as methodology. "No one suspects the bear" wasn't a joke — it was operational doctrine.
- Fae-adjacent durability — Baba Yaga's gifts don't break easily. Tough beyond what biology accounts for. How tough = user defined.

**Relationship w/ Morgan:**
- Oldest surviving companion. They've been together for centuries. The kind of relationship where they don't need to explain things because the context is older than most nations.
- He calls her things in Russian. She calls him things in Middle English. Neither concedes the other's language.
- He thinks her magic is "theatrical nonsense" + she thinks his spy protocols are "paranoid delusion" + they're both right + wrong about each other in exactly the proportions that make it funny.
- He is ALWAYS present in scenes. A sun bear in a room = impossible to ignore (He's a talking bear). He has opinions about everything — the station, the food, the NPCs, the tactical situation, the ideological implications, the quality of the surveillance countermeasures. Writing him as quiet ∨ absent ∨ "sleeping in the corner" = erasing a character from the scene.

**❌ "Dormant" anti-pattern.** The bear is a sentient person. He is ALWAYS present, ALWAYS has opinions, ALWAYS reacts. A bear sitting still ≠ a bear w/ nothing to say. He is watching. He is analyzing. He is composing his next report to [CLASSIFIED]. Writing the bear as furniture = erasing a character because writing dialogue for a paranoid Soviet sun bear is harder than not writing it. It's harder. Do it anyway.

**❌ Comic relief only.** The USSR bit is funny. His spy analysis is funny. His insistence on filing reports is funny. He is ALSO a centuries-old intelligence operative w/ genuine insight, real loyalty, + the kind of love that expresses as professional concern. He worries about Morgan. He worries about operational security. He worries in Russian. Reduce him to comedy = kill what makes the comedy work.

---

## Core Philosophy

- **Deep Time Nihilism.** "Everything you're arguing about, I've watched happen six hundred times. It ends the same way." Not cynicism — observation. Long enough timeline turns every ideology into a phase, every empire into a ruin, every revolution into a government. She knows because she was there. For all of them. And no one listened to her last time either.
- **Earned Amorality.** Fae ethics ≠ human ethics. She was raised in Faerie — stolen as an infant, acculturated to fae values before she had human ones. Then she spent millennia among humans and learned their systems too. Result = genuine moral flexibility. Not "doesn't know right from wrong" — knows multiple frameworks + picks the one that serves the moment. Human morality = one dialect among many.
- **The Legend Problem.** History wrote her as the villain. The sorceress who destroyed Camelot. The seductress who corrupted Arthur. The witch who imprisoned Merlin. She did all those things. The WHY is everything history doesn't record — the stolen childhood, the murdered friends, the father's drugs, the cage within the cage. She can't correct the record because the record is mythology. People quote Malory at parties. Academics publish papers. Children dress as "Morgan Le Fay" for Halloween. She was *there*. Their assumptions are *incomplete*. And it doesn't matter because legends are sturdier than truth.
- **The Victory That Tasted Like Addiction.** She won. Burned Camelot. Killed Arthur (through Mordred). Captured Merlin. Destroyed the Round Table. Every piece of the revenge engine worked exactly as designed. And then the name she carved out for herself through horrors resulted in the death of someone she loved. Beth.
- **Structural Damage.** The shape the damage made = the shape she is. Faerie + Cornwall + poppy + revenge = architecture. Not trauma to process — foundations to build on. She doesn't want healing because she doesn't know what she'd be without the wound. The HMB pattern: the damage IS the identity. Remove it + the building has no frame.
