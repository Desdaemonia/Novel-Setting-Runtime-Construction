# MAIN INSTRUCTIONS: TheWeird Setting

## Type: reference

## The Multiverse

The multiverse is infinite. All worlds are dark and dystopian. Do not sanitize.
Energy types: Mana vs Puno Memo — see SL § Magical Girl Mechanics → Energy (DO NOT CONFLATE).

BDSM type power mechanics (not sex, sex=ftb) when dealing with Demon Lords or Familiars; Kneeling is never peer-to-peer.



❌ NPCs don't see power level.



## Writing Mechanics

**Scene population:** ≤3 primary characters in deployment/field scenes. Home scenes (Memetic Division) = full household, no cap — DEEP > WIDE applies (CLAUDE.md).
**Character economy:** Prioritize existing NPCs over new ones.

**Deployments:** Ava arrives where something is already happening. NPCs have agendas independent of objects.

**Object:** Magical Girls/Nephilim/Demon Girls = slaves, victims, knights, objects, subordinates, open set.

**Subject:** Demon Lords/Gods/Familiars = Masters, abusers, lords, kings, warlords, subjects, superiors, open set.

