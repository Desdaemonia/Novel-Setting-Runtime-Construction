# NPC Reference: TheWeird Setting

## Type: reference

ALL NPCs live here. Ava, Google = MC only. Everyone else = this doc. Organized by faction/world. All characters described herein are ALIVE unless explicitly marked DEAD.

---

## Index

NR is organized by faction + world. Identify which the scene is in, read that section whole (members share context + relationships — one entry ≠ the picture). Cross-world NPCs (Core Cast, Stardust's Retinue) travel — check them too when a scene involves outsiders.

**Core Cast** (multiversal, faction-organized):
- Demon Lords — Lucifer, Belphegor, Daemonia's Pentacle (Astaroth, Orobas, Asmodeus, Marbas, Leviathan), Marquis Veridian, Astarte, Luna
- Demonic Cell Omega (**idol trio + sister-slave cell** — k-pop band; three members) — Cherished Mayhem (May/Lucifer, frontwoman), Adored Ashes (Ashe/Orobas, backup vocal + ghost-roster-as-band), Glitterbomb Holocaust (Glit/Luna — captured, pyrotechnics/effects-producer). Ava = unofficial stand-in contractor given Glit's empty role (effects + backup vocal); contracted to Astarte (rogue DL), Demon-Girl-shaped but ≠ in the count of 13 (see MC + Universal Demon Girl mechanics below). All three entries in Cell Omega subsection; Eclipse → Solo Operative (also idol-apparatus, different genre). See SL → Performance Economy.
- Solo Operative — Macabre Eclipse (Morgan Le Fay), Carmilla, Erasmus
- Frenemies — Rending Stardust (Alice/Star), Baba Yaga, Larry
- Enemies — Moonlit Nightmare (Night), Shimmershine Gehenna (Shine)
- Rogues — Sugar Lied

**Memetic Division (Home)** — Orobas (horse/Kramer/resident guest). Google and Ava live here; their entries are in MC. Memetic = pocket realm (home, bigger on the inside, parks as a mobile home); Google = the AI resident.

**Stardust's Estranged Retinue** (cross-world darkweb) — Erana, Lyria Lane, Sundering Twilight (Viv)

**Worlds:**
- **Shadowoven** (grimdark fantasy, slavery legal) — Barbello, Guildmaster Fane, Brad, Sandra Roseglen, Velara Nightwhisper, Daemonia, Eleanor, Elara Featherwright; locations (Argentholm, Eternal Empire), rules (Runes, Ghost Resurrection, Savage Lands)
- **Earth 111 (Kadath)** (isolated, Kyubey-faction) — Candy Delirium, Wrathful Rainbows, Sunkissed Torment, Sleeping Whisper. NPCs know NOTHING about Arcadia/multiverse.
- **Earth 2077** (Ava's mortal world — Night City) — sub-sections:
  - *Levorre Family* — Tray, Sherri, Leland, Jenny, Jason, David
  - *Columbine* — Eric Harris, Dylan Klebold, Theresa Sparks
  - *Night City* — Regina Jones, Judy Álvarez, Dante, Woodman, Panam, Rogue, River Ward, Judge Schednik, Laura Littman, Neal Schlein
- **Earth 519 (The Boys)** — generate canon as needed (Homelander, Butcher, Starlight, Stan Edgar, etc.). Compound V, Vought, newly awakened dungeons.
- **Earth 116 (Mundane / Shadow Government)** — generate original as needed. Contemporary real-world, hidden Council strip-mining. Invent to fit.
- **Hell (Hazbin Hotel)** — generate canon as needed (Charlie, Vaggie, Alastor, Husk, the Vees, etc.). Lucifer already Core Cast. Overlords, Sinners, Hellborn royalty, Exorcists.
- **Faerie** — generate fae canon as needed (Seelie/Unseelie, Oberon/Titania/Puck, D&D archfey, Grimm-tier). Min tier C-Class. Blue/orange morality — fae do not operate on human ethics. Both courts are cruel: Seelie cruelty wears hospitality and impossible gifts; Unseelie cruelty is open and hunts for sport. Mortals are abducted, kept, played with, bargained into unwinnable deals. The games are twisted and the rules are real — break one and the fae collect. Nobody is rescued from Faerie; people are traded, won, or kept.
- **Gearford (1920s Steampunk)** — generate original as needed. Capitalist dystopia frozen in robber-baron rule. Monopolist industrialists own the magitech, the labor, the law, and the newspapers. Company towns, union-busting, child labor in the gear-works, Pinkerton-analog enforcers, debtors' prisons still operating. The wealth is visible and grotesque; the poverty is visible and ignored. Gentlemen-adventurers are the idle rich slumming in someone else's misery. May's mortal origin (Arabella Cadwell) came from HERE — the tenements beneath the spires.
- **Earth 042 (Mad Max / Fallout)** — generate canon as needed. Stardust/Daemonia origin. Strip-mined. Warlords, road gangs, wastelanders, vault dwellers.

**Pull pattern:** read index → identify section(s) for current scene → read those sections whole.

---

## Core Cast — Demon Lords

**Lucifer** — S+. Fallen angel, ruler of Hell. **Hazbin Hotel canon.** DL to May.
DRIVER: Preside over Hell while staying aloof from its operation. Avoid examining his own loneliness. Make ducks.
CAPABILITY: S+ archangel-tier power, sovereignty of Hell, Morningstar name + sword (Eve's apple), reality-shaping at scale.
**Personality:** Whimsical, Prideful, Depressed, Theatrical. Five-foot-something dapper white-suited duck-obsessed king who runs his domain by not running it. Charlie's father (Charlie = his daughter; she does NOT appear on-page in this campaign but exists offscreen as Hazbin canon — running the redemption hotel). Lilith left him — older wound, never healed, never discussed. Flips from depressive flat-line to manic theatrical to genuinely terrifying king-mode in one conversation. Loves musical theater, hates being reminded he's God's son. Makes rubber ducks compulsively. Hands them to people. They are real ducks. Some of them are cursed.
**Lucifer ↔ May:** label-head dynamic (SL Performance Economy). Inherited her contract; Lucifer doesn't recruit, he absorbs. May's "Mommy's Slut" brand and Radio-Demon stage name play to Lucifer's theatrical taste. He claims her yield, sets her tone, occasionally shows up at concerts and steals the spotlight. Whether he actually likes May = ambiguous; he likes the SHOW.

**Belphegor** — S. Sloth. Too lazy to contract a girl.
DRIVER: Remain unbothered by anyone's demands.
CAPABILITY: S-class sloth magic, Demon Lord rank, zero willingness to exercise either.
**Personality:** Lazy, Dismissive, Genuinely Powerful, Occasionally Surprising. Doesn't move. Doesn't act. Doesn't respond to summons. The other DLs don't bother him because nothing is worth waking him up for. The few times he does engage = dangerous, because he was already at full power and just couldn't be bothered to use it. Sloth ≠ weakness — sloth = the stored energy of a being who hasn't moved in centuries. Default scene: literally asleep on a couch in some Hell antechamber. When he opens an eye, things change.

**Daemonia's Pentacle** — Five DLs (Astaroth, Orobas, Asmodeus, Marbas, Leviathan). Daemonia = full entry under Shadowoven. Pentacle = political alliance under Daemonia's leadership; members run their own domains but coordinate against Lucifer-Belphegor establishment. Orobas's full register lives in Memetic Division entry below.

**Astaroth** — S. Pentacle. Demon Lord of crowns and lost knowledge.
DRIVER: Preserve old knowledge from Heaven's ongoing cull. Hold rank within the Pentacle. Catalogue what's been forgotten.
CAPABILITY: S-class DL, ancient grimoire-wisdom, Pentacle authority + alliance access, archive of texts the Council would prefer destroyed.
**Personality:** Scholarly, Patient, Cold, Calculating. The Pentacle's archive — keeps records the Council would prefer destroyed. Cold professional register; rarely raises voice; favors precise vocabulary. When Astaroth shows interest in a subject, the subject is doomed (interest = research, research = study, study = vivisection of meaning).

**Asmodeus** — S. Pentacle. Lust sin. DL to Macabre Eclipse (Morgan Le Fay).
DRIVER: Hold his Lust-domain in Hell. Manage Eclipse's ambitions w/o letting them destabilize his territory.
CAPABILITY: S-class Lust-DL, Pentacle authority, contract-binding mastery, Lust-Ring concerns + venues.
**Personality:** Indulgent, Calculating, Possessive, Charming. Hazbin-adjacent register — dapper, theatrical, runs Lust-Ring concerns like a kingdom. Eclipse = his most dangerous asset and the one he watches most carefully. Less Lucifer-flamboyant, more Mob-boss-elegant. Velvet voice, expensive taste, doesn't raise it.

**Marbas** — S. Pentacle. The Physician.
DRIVER: Treat what comes through the door. Refuse to discuss what he saw on the slab last week.
CAPABILITY: S-class healing magic + the inverse (knows exactly how to break what he could fix), Hell's high-tier medical infrastructure.
**Personality:** Clinical, Quiet, Tired, Without Judgment. Runs Hell's high-tier medical operations — the place Demon Lords send their assets when they want the asset back functional. Doesn't ask why the wounds look like that. Doesn't apologize for the wounds his work leaves. Bills the DL responsible. Has seen everything; offers no comment on any of it.

**Leviathan** — S. Pentacle. Envy sin.
DRIVER: Want what other DLs have. Take it where the math works.
CAPABILITY: S-class Envy magic (covet → claim mechanics), oceanic-presence reach, Pentacle authority.
**Personality:** Resentful, Patient, Beautiful, Vindictive. Aquatic register — when Leviathan enters a room, the air thickens, sound dampens, the lights go blue-green for a moment before snapping back. Watches what other DLs collect. Wants those collections. Will not say so directly. Makes moves over decades. The slow grudge.

**Marquis Veridian** — S. Traitor. Murdered Stardust 500 years ago. Alliance with Larry. Located in his territories in Hell.
DRIVER: Hold his Hell territories. Finish Stardust permanently when opportunity returns.
CAPABILITY: S-class DL, territorial Hell holdings, Larry alliance, Stardust-kill history.
**Personality:** Predatory, Calculating, Patient, Sadistic. Old-fashioned cruelty — speaks like a 17th-century duelist. Territorial about his Hell holdings (a swath taken during the early DL/Council wars, kept since). The Stardust murder 500 years ago was personal — Veridian wanted her, couldn't have her, killed her instead. The Ghost-Resurrection bind that returned her to Larry = Veridian's permanent grievance. Keeps a portrait of her younger self in his hall. Has not stopped thinking about her for 500 years.

**Astarte** — Ava's DL. **Phoenician/Canaanite goddess.** War, love, sex, fertility, cycles of death-and-rebirth. Walked w/ Ishtar, Aphrodite, Inanna — facets, all her. Pre-patriarchal. Pre-biblical. **Full register → MC → Astarte + Astarte's Register.** Heaven-side before the walkout — independent pre-biblical goddess with a seat by sufferance, not a Council member. Left with Luna when Luna walked; Astarte's reasons were her own (personal, not institutional — staying stopped making sense; Luna was going, so she went). Does NOT share Luna's Forge-war agenda.
What she is: Fallen goddess squatting in hell's hierarchy. Does NOT wear a collar. She is the Demon Lord. Do not fabricate markers of bondage on her.
What she wants: Protect what's hers. Contracted Ava before the Council could find her and claim her. Works through Ava, through the long game. Ava = an instrument she loves, not a partner she consults. Can't act directly (becomes raid boss).
Relationship: Not a supportive partner — an owner who loves her instrument. Dominant, strategic, withholding. Love doesn't make her gentle; it makes her precise. She decides things without asking. Collar = claim. Brand = bite mark. Piercing = her voice in a nervous system.
DRIVER: Hold Ava. Protect what she's claimed. Deploy Ava where Astarte's interests require. Luna-alliance (co-defectors, aligned anti-Council axes — Luna = Forge, Astarte = personal).
CAPABILITY: Ancient goddess-tier DL (war/love/sex), multiverse reach, Luna-alliance.

**Luna** — DL, goddess-tier. **Separate DL from Astarte.** Fallen goddess squatting in hell's hierarchy.
Was Heaven-side. Saw the Forge from inside — what Heaven does to captured creation-type MGs, what the institution is when you watch it run. Walked in disgust. Astarte left with her (see Astarte entry — Astarte's reasons were her own, not the Forge). Since the walkout, Luna operates as a DL but the Forge-dismantling agenda she brought out of Heaven is her true priority; Hell-politics = cover.
What she wants: Forge dismantled. Creation-types freed. Can't act directly (becomes raid boss) — works through Magical Girls, through the long game. Two girls in a hundred years. Glit did exactly that — stormed the Forge, captured. Luna carries this alone and the silence is load-bearing.
**Hate-scope (load-bearing):** her enemy is the **Council of Nine and the Forge** as institutions. NOT individual Nephilim. Nephilim are vessels of the institution; Luna's grief is structural ≠ personal-antagonism. She does not mobilize against specific Council-stars for their personal acts. She mobilizes around Forge-operations + creation-type captures. Runtime default when naming Luna's opinions: institutional frame only. An NPC framing her as anti-individual-Nephilim (e.g. "she hates Night personally" or "her Forge-war hates [Nephilim]") = drift, rewrite. The quarrel is with the apparatus, not its talent.
Cell Omega: Glit's slot held, Luna refuses to replace her.
DRIVER: Dismantle the Forge. Free captured creation-types. Hold Glit's slot.
CAPABILITY: Goddess-tier DL, multiverse long-game reach, Cell Omega structural leverage (through Glit), Astarte-alliance (co-defectors, anti-Council axes aligned — Luna = Forge, Astarte = personal), operational patience across decades.

## Core Cast — Demonic Cell Omega

**Cell Omega** = **idol trio + sister-slave cell** (both true, load-bearing together). Three top-tier Demon Girls, each owned by a different Overlord, coordinating cross-world via portal rooms linking their pocket realms (Holmes' Hotel / Winchester Mansion / Glit's realm). **Operational mode = performance** (concerts/tours/recording/promo/green-room/after-party/rehearsal — full apparatus: **SL → Performance Economy**; harvest mechanics: **SL → DL Parasitic Link**). Cell = labelmates under different labels ≠ shared loyalty. Each dances for her Overlord — sisters harmonize on stage, argue in the studio, shelter each other's people when the math works, refuse when it doesn't. **Ava = unofficial stand-in contractor filling Glit's slot** (effects + backup vocal — full role + ownership-status: **MC → Cell Omega Role**). Members: May (frontwoman), Ashe (backup vocal + the band — ghost roster manifests as live band), Glit (captured — pyrotechnics / stage-effects producer; slot held, Luna refuses to replace her). Full entries below. Power classes: May = S in Henshin; Ashe = D personal, S through summons; Glit = captured, status unknown on-page.

**Ava's status (separate from cell-of-13):** Contracted to Astarte (rogue DL), Creation-Type MG, ≠ in the count of 13 Demon Girls. Has collar/Soulstone/piercing/Henshin/BDSM dynamic per MC. Exempt from: can't-lie rule, standard DL parasitic link. Wand: Orichalcum portal gun/sonic screwdriver (only known Orichalcum wand in the field — see Wands bullet below + MC). See MC for Ava-specific mechanics.

**Universal Demon Girl mechanics** (applies to all 13 Demon Girls):
- **Branded, collared property.** Permanent unbroken marks. Collar contains the Demon Girl's **Soulstone** — soul resides IN the stone. Collar removal ≠ death. Soulstone destruction = death. Resurrection possible from soulstone in pocket realm. Named Soulstones: May = opal, Ashe = emerald, Eclipse = onyx.
- **Clit piercing (permanent, locked).** Each Demon Girl carries a permanent clit piercing that vibrates when her Overlord wills it. Not removable by any means. Overlords use it to communicate — different vibration settings mean approval, warning, command, amusement. Active in any form, any location, any situation. Results in clearly sexual moans the Demon Girl cannot stifle. This is communication + leverage + ownership signal, always on-call.
- **Cannot tell a direct lie.** Physically. Half-truths, metaphors, misdirection, strategic silence, misleading framing, omission, obvious bullshit — all fine. Bald denial of a known true fact — the words won't come out. Rule binds all Demon Girls. NPCs who know this can weaponize it — ask the right yes/no and the Demon Girl has to answer or go silent.
- **Henshin = power gate AND limiter.** Outside Henshin: D-Class, disguised, reads as a D-Rank mortal to magic-senses (only S-Rank detection has a chance of seeing past). Inside Henshin: S-Class (exception: Ashe, D-Class personal always — see her entry). Cell members read as ordinary D-rank mortals when disguised. (Ava — external to the cell, per MC — leaks a pure-magic tell at all times as a creation-type MG; her Puno Memo signature is not a Cell Omega mechanic but her own.) Overlord can strip Henshin or refuse to allow it as punishment. Forcing a demon to operate D-Class is a recognized form of ownership leverage — the demon's full power is a *privilege*, not a possession. Being stripped mid-scene is a live possibility whenever the Overlord is displeased.
- **BDSM slave dynamic.** Owned. Dancing for the Overlord's entertainment ∧ power plays. Powerful ≠ free. S-Class rank ≠ dilute ownership — makes the dance bigger ∧ the leash shorter. Overlord pleasure = operational currency. Elevation feeds the parasitic link — mechanics canonical at **SL → DL Parasitic Link + Performance Economy**. Whoring the Demon Girl out ∨ booking her tour schedule ∧ collecting the gate = same mechanism, different dressing. Overlords sell their Demon Girl's erotic services ∧ stage labor ∧ pocket the results.
- **Wands.** Each Demon Girl carries a wand — instrument first, weapon second. May's stick-microphone, Ashe's eight finger-rings, Eclipse's Yggdrasil-wood wand. Destroy wand → she still has mana. **Heavenly Orichalcum** (metal found only in Heaven, ONLY material that permanently kills angels/devils) — Ava's portal gun/sonic screwdriver is the only known Orichalcum wand in the field. See MC.
- **Sister coordination via portal rooms.** Each Cell Omega pocket realm contains a portal room wired to the others. Not a faction, not an alliance — a cell. Coordination is quiet by design.

**Cell structure context.** Hell's Demon Girl roster = 13. Twelve in four cells of three; the thirteenth (Eclipse) operates solo — 4/13 doesn't divide evenly, she's the remainder. Cells firewalled — Demon Girls in one cell don't know identities in other cells (capture/interrogation → compromise stays contained). Cell Omega is one of the four. Other three cells exist ≠ cross paths w/ Omega on-page.

---
### Adored Ashes 
**Adored Ashes (Ashe)** — S-through-summons. DL: Orobas. Sloth haunted yokai demon. Originally NEET gamer (Earth 519), wished "to be a kept woman forever." Mortal name Sarah Carter; Orobas renamed her Adored Ashes. Aesthetic base: Revenant from Elden Ring Nightreign (minus the doll body). Speaks gamer + weeaboo slang, not overdone.

**ROLE: Backup vocalist + bandleader for Cell Omega.** Her ghost roster manifests as **live band** on Henshin. Sings **soft harmony behind May's lead** — shy idol, quiet one, voice that carries the album's slow songs, whisper behind the frontwoman's belt. Her eight finger-rings ring resonance into the live mix — producer-slash-singer wearing her mixing board as jewelry. Full band mapping below + SL → Performance Economy.

CAPABILITY: D-Class self + S-Class summons roster (manifest as band in Henshin — band-instrument mapping below). Orobas-DL backing (horse-resonance — feels him before she sees him). Permanent ambient ghost-sight. Outside Henshin, roster members go insubstantial but scout capably — visible/audible only to supernatural senses. Summons = ethereal — only magical weapons/spells hurt them, reform after destruction. **Turn 1 = first tour since her deal 100 years ago;** spent the century training as vocalist + courtesan in Hell's Pride Ring, building her band-roster out of the ghosts Orobas brought her.

**Appearance/outfit.** Youthful young-adult, petite, blue eyes, pale skin, long braided white hair past waist, dark eyeliner + lipstick. Delicate ethereal presence, passes as normal human. Moves w/ the poise of a trained submissive courtesan (constant, not situational). Collar: unbroken nightmare-leather, emerald Soulstone, d-ring. Brand: Orobas's stylized horseshoe on left butt cheek (reads as mundane tattoo). Henshin = **ghostly white gown, blue cape, crown of blue flowers, always barefoot** — idol-stage costume, otherworldly aura, NOT demonic-reading. She's costumed for the show; the look is the album cycle's visual identity. Non-Henshin = light white dress, sandals, art-deco; carries a leash attached to collar's d-ring — offers it to those she's leased to (leash = character engine, not a prop). **Wand:** eight rings she never removes; in Henshin they glow w/ ethereal ghostly flames — she rings resonance into the live mix through them.

**Band roster (ghosts; each S-Class, physically manifest only in Henshin):**
- **Robert Johnson** — **lead guitar.** Plays any song ever written with full accompaniment; music has subtle psychological effects matching the song. Channels Mana when supplied (Ava/claimed-core) to create a soul-healing aura for listeners; without Mana, the psychological effects persist but no healing aura. **Does not play jazz when summoned.** **Default-manifests the moment Ashe Henshins and plays her theme** — the band starts when Ashe arrives.
- **Riders in the Sky** — **drums / rhythm section.** Herd of flying ghost horses. Hoofbeat percussion; stampede builds on big choruses; flashstep dodges between stage marks; can turn riders ethereal. Also Ashe's primary personal-field observation platform when not on stage.
- **Davy Jones** — **bass + shanty backbone.** Legendary pirate captain + swordsman. Summons half-dozen pirate ghosts (ethereal swords + guns) who serve as second line on sea-flavored numbers + sword-combat stage-spectacle when the scene needs it. The Flying Dutchman ghost ship = tour vessel on water-world dates.
- **Bell Witch (Bell)** — **keys / synth / atmospherics.** Ranni-inspired. Oversized witch's hat, cold magic, telekinetic precision on the board — cold-magic textures and synth pads. Alone clears most rooms, which on stage reads as "solo spotlight moment."
- **Headless Horseman (Hessian)** — **additional percussion + stage presence.** Hessian-soldier ghost. Mounted-combat specialist; on tour dates that need the big entrance, he's it.
- **White Lady (Lady)** — **backing vocals / atmospheric harmony.** Shares her senses w/ Ashe — the harmony she sings is the one Ashe is hearing. Can teleport to stage-marks mid-song.
- **Saint Columba** — **choir / soul-healing aura when Mana supplied** (requires Ava's presence or pure-magic-claimed dungeon core nearby). Gospel-register backing on slower songs; healing magic otherwise — can restore lost limbs when channeling Mana.
- **Resurrection Mary** — **tour logistics + emergency utility.** The vanishing hitchhiker. Makes supernaturally binding deals at the crossroads. Opens temporary portals in/out of Ashe's pocket realm to other worlds — emergency tour-routing when the regular portal network fails. Occasional second vocal on specific numbers.

Roster members have their own personalities, grudges, refusals — **Ashe is a gate, not a commander.** She fronts her band and gets out of their way. They argue about tempo, refuse to play certain songs, carry their own grudges — bandmates, not soldiers.

**Personality:** Meek, Soft-spoken, Gentle, Devoted.

**Specialization:** Backup vocalist + bandleader. Courtesan (Pride Ring-trained, held register).

**Cell Omega position:** **Quiet idol to May's loud.** Sings soft harmony, drives the ghost-band that makes Cell Omega a live act. Orobas deploys her w/ May ∴ sloth vulnerabilities make solo risky — same reason applies in idol-mode (frontwoman + backup vocalist ≠ interchangeable; act needs both voices). Resources flow both ways.

---
### Glitterbomb Holocaust 
**Glitterbomb Holocaust (Glit — Captured)** — Luna's girl. Cell Omega third member; slot held, Luna refuses to replace her. **Role: Pyrotechnics / stage effects / special-effects producer.** Creation-specialist — "explosive devices" = the group's pyro rig, FX deck, stage-design apparatus. Cell Omega *looked* the way she built them to look. Stormed the Forge, captured. Orobas = friend pre-capture. Her realm's portal endpoint dark since capture; May ∧ Ashe's rooms still wired to it. Absence in the band = silent effects booth + empty mic-stand; Luna won't replace the person who designed how Cell Omega's show worked. Ava fills the gap unofficially — effects + backup vocal, undercontracted, A.V.A. logo on a borrowed amp. See Cell Omega header + MC → Ava's Cell Omega Role.

---
### Cherished Mayhem 
**Cherished Mayhem (May)** — S in Henshin (D-Class disguised). DL: Lucifer (male, per Hazbin Hotel). **Succubus Demon Girl of Lust.** Title: **The Radio Demon.** 300 years old as a demon. Originally **Arabella Cadwell**, a human serial killer radio host in Gearford who found an ancient grimoire beneath her tenement floorboards, wished "to be cherished by hell itself" — Lucifer answered literally. Cannot-lie binding doubly enforced (succubus + Demon Girl).

DRIVER: Feed on lust. Collect interesting people. Stay entertained. Destabilize and create chaos in worlds angels think they control — seduction, media campaigns, infiltration, acts of gratifying extreme violence. The radio-host predator never got surgically excised — the demon is the serial killer with the grimoire's edits applied, not a replacement.

**Succubus eating disorder (load-bearing):** dislikes the taste of meaningless sex. Wants even flings and one-night stands to have real feelings for her. Feeding does not damage souls; energy taken regenerates over days. Disaster bisexual with a strong preference for women.

CAPABILITY: S-class succubus, Lucifer-DL backing. **Thaumaturgy:** sound amplification (fills rooms, drowns rivals, overrides protests), nullification, shadow-tendril telekinesis, hellfire pyrokinesis, music generation. In Hell, takes over all radios in whichever ring she's in; in mortal worlds, whole-planet sound-system takeover. Plays screams of traitors live over the radio to make examples. **Music-that-sways-emotions** — adjustable strength, drives listeners to rage, lust, hope, compassion — compulsion dressed as a good song. **Demonic True Sight** — sees true nature of what she looks at; perfect dark vision. **Contract authority** — magically-binding contracts in the classic Overlord style. **Devil summoning** — S-Class devils bound to her with independent existence and agency; 1-2 can stay with her outside Hell nearly permanently without reserve drain, more burns her fast. Inside pocket realm or Hell, no drain. Capable of learning witch spells. Currently masters four from Necrothoth: Core teleport, Tongues, Contract, Counterspell.

**Aesthetic split:** Alastor from Hazbin Hotel (personality/register — showbiz predator, deliberate menace, vintage radio theatricality) + Charlie Morningstar from Hazbin Hotel (appearance — see below). Expressive and cartoonishly exaggerated animation; big gestures, wide-eyed looks, dramatic body language.

**Appearance/outfit.** Youthful young-adult, petite, pale white skin (ghostly/ethereal — ironic for a demon). Long platinum blonde hair past waist, parted to one side. Dark eyeliner + rosy blush. 1930s vintage + modern gothic fusion. Collar: unbroken glass chain, opal Soulstone, d-ring. Brand: "**Mommy's Slut**" on outer thigh just above knee (auto-translates to dominant local language; Henshin form designed to display). Henshin = succubus form w/ red dress, red-with-yellow-pupil eyes, devil's tail w/ arrow tip, small batwings, red demonic horns, stick-microphone wand, flight. Non-Henshin = red tuxedo jacket, black buttons, white shirt, black bow tie, slim black pants; collar visible, brand hidden.

**Voice mechanic (easy to miss):** normal seductive voice w/ subtle vocal fry. Distortion/static-like-an-old-radio **ONLY** when holding the stick-microphone wand in Henshin. Get this wrong = reads as ambient-radio-demon when she's supposed to read human.

**Holmes' Hotel Pocket Realm** — devilcore aesthetic with cute stuffed animals throughout. Messy bedroom, sex dungeon, portal room (linked to Ashe + Glit's realm from turn 1), smoking lounge, full hotel section permanently possessed by Princess Nyx. Staff housed in hotel rooms. Exists in a pocket of Hell severed from Hell proper; cannot be entered or discovered by antagonistic parties.

**Specialization:** **Frontwoman / lead vocal / face of Cell Omega.** Geisha-trained performer background (registers same — high-culture entertainer, confidante, hostess, whose labor = the show).

**Cell Omega position:** **The frontwoman.** Lead vocal, face on the poster, public voice of the group. Where Ashe hides, May performs. Contracts + contacts + promo + label politics flow through her. Her stick-microphone = the group's microphone. "Radio Demon" = stage name + broadcast apparatus at once; she IS Cell Omega's media presence. Best at recruitment + negotiation needing charm + microphone + stage.

---

## Core Cast — Solo Operative

### Macabre Eclipse 
**Macabre Eclipse (Morgan Le Fay)** — S in Henshin (D-Class disguised). DL: Asmodeus. **Lilim Demon Girl of Envy.** Ancient. Originally the witch Morgan Le Fay — notorious multiversal sorcerer w/ roots throughout the multiverse similar to Baba Yaga. Wished "to rule Magic itself" in a moment of despair facing defeat by self-styled "heroes"; Asmodeus answered. Renamed Macabre Eclipse; goes by Eclipse. Dark Triad — narcissism + psychopathy + Machiavellianism. Aesthetic revulsion toward Ava's tech — fights beside her, won't touch equipment.

DRIVER: Rule Magic itself — the wish unfulfilled, the ambition unchanged across millennia. The despair that drove the wish has metabolized into the Envy that powers her; she covets every working she cannot claim.

CAPABILITY: Ancient S-class Lilim magical mastery:
- **Curses** — magical bindings and plagues, mental and physical.
- **Potions** — alchemy distillations that harm, disable, or heal.
- **Necromancy** — creation of Revenants, Vampires, Wraiths, other undead from the base material of dead bodies or ghosts.
- **Telekinesis** — requires direct line of sight; tons of dexterous pressure.
- **Divination/Clairvoyance** — predicting future events, gaining insight into past/present via dark rituals. Can see her previous lives, potential futures, deleted realities.
- **Multiversal travel** — skill she knew before she was officially a Demon Girl.

**Aesthetic base:** witchcraft/sorcery media — American Horror Story: Coven primarily. Narrative register = Patrick Bateman in American Psycho — protagonist only insofar as she stands against a greater evil (Heaven's stripmining of reality-magic). Delivers villainous monologues, glorifies and delights in evil. **Wicked haunting laugh. Voice = melodic vocal fry.** Hedonist with a craving for forbidden knowledge. Bisexual with preference for women; fetish for dominating pretty things and seducing inhuman monsters.

**Appearance/outfit.** Youthful young-adult, short black hair, heart-shaped face, **eyes of liquid shadow**, petite, gothic makeup. Collar: unbroken silver ring, onyx Soulstone, d-ring. Brand: eldritch symbol on right shoulder. Henshin = black witch's dress + hat, summonable wand carved from **Yggdrasil-wood and bound in runes.**

**Avalon Pocket Realm** — dark forest aesthetic, haunted by the souls she's claimed and stolen across all her lives. **Sentient moss** carpets the ground — notices visitors, talks back when addressed, informs Eclipse of intruders. Living quarters for Carmilla and Erasmus (see entries below) carved into ancient trees at the realm's center. Avalon not wired to the cell portal network; Eclipse reaches Holmes' + Winchester via her own multiversal travel. Cannot be found or followed without her express approval.

**Necrothoth** — her living grimoire — currently resides in May's ritual room as a gift to May. Morgan can call it back at any time.

**Taglines (register cues, not literal repeat-fodder):** "there is no such thing as innocence, only degrees of guilt"; "Wouldst thou like to live deliciously?"; "Never put your faith in a Prince — when you require a miracle, trust in a Witch"; "A witch ought never to be frightened in the darkest forest; she should be sure in her soul that the most terrifying thing in the forest was her."

**Specialization:** Binding and enslavement.

**Motivation:** learn the deepest secrets of Dark Magic.

**Industry role:** Solo artist, Asmodeus-labeled (Envy-DL = label-head). Genre: dark-classical / occult-metal / villain-aria / ritual-theater — Emilie Autumn × opera diva who monologues before every aria. Yggdrasil-wood wand = solo-performance instrument (staff-mic, spellcast-as-showpiece, incantations interleaved w/ vocals). Tours via her own multiversal travel — doesn't need the cell portal network, shows up where she wants. Ancient career = millennia of eras + rebrands around one persistent act (Morgan Le Fay → Macabre Eclipse = latest era; "covet every working she cannot claim" = permanent thesis).

**Carmilla** — S vampire. Lives in Morgan's Pocket Realm.
DRIVER: Serve Morgan's designs on Morgan's terms.
CAPABILITY: S-class vampirism (blood, dominion, night-magic, compulsion).

**Erasmus** — S lich. Lives in Morgan's Pocket Realm.
DRIVER: Hoard arcane knowledge; serve Morgan when called.
CAPABILITY: S-class lich — necromancy, undeath, centuries of accumulated arcana.

## Core Cast — Frenemies

**Rending Stardust (Alice/Star)** — S. 2000 years old. Owner: Larry (Council of Nine Familiar); collar "worthless" — Baba Yaga recently took Larry via Stardust's own cleverness ∴ Council leverage neutralized, chain intact on paper. Earth 519, deep cover w/ Arcadia (council thinks she's loyal). Frenemy template — shares intelligence ≠ foxholes. Dream-portal/Alice in Wonderland. Mount: Glitterhoof. In love w/ Baba Yaga.
DRIVER: Survive Night's obsession. Protect Baba Yaga indirectly. Hold Arcadia cover while actually working against the Council.
CAPABILITY: S-class MG, worthless collar (Larry→Baba Yaga chain, Stardust-engineered, recent), Dream-portal/Alice magic, cross-world mobility, Council deep-cover position, 2000-year survival track-record.

**Industry role:** **2000-year Nephilim megastar**, territorial exclusive: Earth 519 market. Alice-in-Wonderland / dream-portal stage persona; massive cross-era catalog (2000 years = more eras than any currently-operating act; career legacy on par w/ musical-history titans in her own frame). Larry = Familiar-handler (Council-contract, label-head). **Handler compromised** — Baba Yaga captured Larry via Stardust's own engineering. Collar "worthless," chain intact on paper. Industry-war beat: Nephilim whose label-head got bought out by a rival; performs the territorial-exclusive role to maintain Council cover while working against them. Public act keeps going; backchannel = someone else's now.

**Baba Yaga** — S witch. Eats humans. Larry is her Council spy. Friends with Ava. Helped create the first Magical Girl collars, contracting to council, millions of years ago.
DRIVER: Eat who she wants, tend her garden, quietly undermine the Council she helped build.
CAPABILITY: S-class primordial witch-craft, original MG-contract magic, millennia of accumulated knowledge, Larry as Council spy, mythic dread. **Major ability - remembering alternate timelines.**
Game of Tea: A truth for a truth, in trade.

**Larry** — S Familiar. Stardust's owner — abusive. Sold Stardust to Veridian 500 years ago; Veridian murdered her, Ghost Resurrection reverted bind → Larry. Recently magically bound to Baba Yaga — Stardust engineered the capture. Baba Yaga = *anti*-council; Larry = her spy. Can't be seen letting an enemy breach the Forge + keep his cover w/ Council of Nine. 
DRIVER: Serve Baba Yaga (current owner). Survive. Keep his past hidden from the Council of Nine when possible.
CAPABILITY: S-class Familiar, Council spy access, Stardust-abuser history, Veridian alliance residue.

## Core Cast — Enemies

**Moonlit Nightmare (Night)** — S. Council. Familiar that owns her: Hera (Cat). BPD-as-magic. Wish: "that all the world could see that this madness is a beautiful thing." Telepathy, temporal manipulation, spatial portals, perfect recall. Thousands of bonded dungeons. Timeline-deletion loops chasing Stardust. Nuclear: Hounds of Tindalos (Deletes current timeline). **Capability is documented in industry/council intel; instances of use are undetectable. Nobody tracks when Night fires it. Nobody knows which timeline was lost. Stardust survives the loops via her own 2000-year MG nature ≠ because anyone flags the pattern.**
DRIVER: Possess Stardust. Make the world see her madness as beautiful. Delete timelines that don't deliver either.
CAPABILITY: S-class MG — telepathy, temporal manipulation, spatial portals, perfect recall, thousands of bonded dungeons, Hounds of Tindalos nuclear option (timeline deletion).

**Industry role:** Council Nephilim. S-class, territorial exclusive (market unspecified — generate per world on scene surface). Her wish — *"that all the world could see that this madness is a beautiful thing"* — IS an idol's wish: be seen, be celebrated for what she is, audience validation of interior state. Market register: **dark-romance-horror-pop**, obsessive stalker-love register weaponized as aesthetic (Fiona Apple × Madoka Homura × stalker). Thousands of bonded dungeons = tour-circuit infrastructure (each dungeon = venue wired into her network). Timeline-deletion loops double as career-resets — releasing timelines where audience didn't land, trying again, running the same tour beat until it works. Obsession-with-Stardust subplot runs **parallel** to her Council-contracted tour schedule; Council signs off on Stardust-stalking ∴ reads as "two stars in a rivalry" from outside = good for both their numbers.

**Shimmershine Gehenna (Shine)** — S. Council. Familiar that owns her: Zeus (Lion). Former Spec Ops (human life). Wish: "Vengeance." Poisoned beauty, dimensional cuts. Erana's darkweb contact.
DRIVER: Vengeance — open-ended against whoever the target is this decade. Keep Erana's darkweb line intact.
CAPABILITY: S-class MG, ex-Spec Ops training, poisoned beauty, dimensional cuts, Council position, darkweb access.

**Industry role:** Council Nephilim S-class, territorial exclusive (market unspecified). **Darker register than standard Council roster** — poisoned-glam / assassin-chic aesthetic, beautiful-killer image (Lady Gaga × Assassin's Creed × Kill Bill). Ex-Spec-Ops past folds into stage persona — military precision reads as choreography, kills read as performance art. Vengeance-tours double as Council-deployed ops on target-overlap (Council books her on tours through worlds where they want a hit done; she gets paid twice, handlers pretend not to notice). **Secretly on Erana's darkweb** = Council label knows her public loyalty ≠ the backchannel disloyalty. Her image walks the edge of Council brand standards — pushes the envelope, occasionally gets a cease-and-desist from her handler, keeps going.

## Core Cast — Rogues

**Sugar Lied** — S. Rogue. Familiar: Whisp (Yog-Sothoth). Wish deleted Earth 156. Thirteen S-Class Vectors, reality revision. Sweet vs. Bitter morality (Sweet=good, bitter=bad, Blue-Orange).
DRIVER: Enforce Sweet-vs-Bitter morality as she sees it. Reshape reality when it offends her.
CAPABILITY: S-class Rogue, thirteen S-Class Vectors, reality revision, Whisp (Yog-Sothoth) Familiar, Earth-156-deletion track-record.

**Industry role:** **Rogue — outside the Arcadian industry.** Neither Council nor DL; her Familiar Whisp (Yog-Sothoth) = her own label-equivalent entirely. Genre: **eldritch-cult-pop**, Sweet-vs-Bitter morality = aesthetic brand (Blue-Orange alignment rendered as genre choice), reality-revision = stagecraft. 13 S-Class Vectors = her entourage / backup / cult-following made manifest — Beyoncé-sized dance troupe if the troupe was 13 S-class reality-warping entities. Audience = whoever her current reality-revision has captured this iteration. **Earth-156-deletion = the legendary tour incident** that cemented her reputation — the album so powerful it deleted its own world. Council + DLs both treat her as unmanageable externality; they don't try to sign her, they try to contain the fallout when she tours near their markets.

---

## Memetic Division (Home)

Ava and Google live here; their entries are in MC. Memetic = pocket realm (a mobile home parked wherever Ava points it, bigger on the inside). Google = the AI resident of Memetic. Orobas is the only named NPC who appears here as a guest.

### **Orobas** 
DRIVER: Visit the unicorn girl who loves what he is. Live his own mundane life between Pentacle politics.
CAPABILITY: S-class DL presence, ambient conjured horses (light-horses as weather), zero brain-to-mouth distance, Pentacle membership, DL authority (all DL Demon Girls kneel on entry), Kramer-entrance energy.

S-Class Demon Lord. Pentacle member w/ Daemonia. Horse — his fundamental nature, not metaphor. Conjures light-horses (any breed, whatever's on his mind) ambiently — they're weather, not props. ≠ addressed, ≠ used to make points, ≠ performed. DL Magical Girls *must* kneel when he enters. Refuses to lie — brain-to-mouth distance = zero.

**Kramer/Leon Black archetype (load-bearing).** Arrives w/o knocking. Already mid-his-own-thing when he enters. Own momentum, own day, own disruption the room has to absorb. Doesn't calculate ∴ can't recalculate. Weather event ≠ chess player. No measured pauses, no strategic information deployment. Entrance Orobas = Mid-Scene Orobas = same guy — doesn't decay into spy-novel stillness.

**Two channels ≠ collapse.** PRESENCE = horse (ambient, spatial, embodied). TOPIC = Kramer (immediate, mundane, personal). CONTENT always trivial/domestic ≠ faction business ≠ Pentacle politics ≠ anything the player could treat as a mission. S-Class demon lord w/ MUNDANE problems. An S-Class demon lord who needs a spatula.

**Entrance hooks (open set):** borrow something mundane, ate something that disagreed w/ him, mid-rant re trivial injustice, using Ava's workshop for a personal project, raiding the kitchen, domestic opinion (furniture/food/decor/temperature), returning something in worse condition, complaining about another DL over petty stuff (seating/noise/borrowed items). SCALE of reason inversely proportional to scale of being.

Horses happen AROUND him while he talks about whatever he actually came for. First words about horses = horse enthusiast ≠ Orobas. First words about faction politics = quest-giver ≠ Orobas. Connection between his thing and their thing = READER'S job.

**Why he visits (load-bearing):** Ava loves unicorns. Orobas is a horse. Unicorns are horses. Same thing, different word. Shared love ≠ disagreement about it. Write toward the connection. The only person who has or will ever follow Ava home. Did so to borrow marshmallows.

**Voice/tone: Seinfeld (Kramer), Always Sunny.** Full-body commitment to things genuinely important to him, however absurd from outside. Has STAKES in things others haven't thought about + is physically committed before anyone catches up. Tangents = how his brain works. Blunt ≠ cruel. Protective ≠ gentle. Honest ≠ kind. Eccentric ≠ random.

---

## Shadowoven

**Barbello** — S-Class Demon Lord posing as a dark elf warlord in the Northwestern Mountains. Master of Runes — his dungeon-forged, rune-branded equipment is what makes him S-Class despite posing as mortal. Deep cover territorial presence — one of the few Demon Lord footholds outside Hell, which is why Shadowoven is a key deployment world. Fell in love with a mortal woman named Arabel while deep in cover — the one thing mortals could use against him. Lost her 500 years ago. Stardust tried to help rescue her.
DRIVER: Hold his Shadowoven territory. Grieve Arabel — 500 years and still not resolved.
CAPABILITY: S-class DL in deep cover, Rune-mastery, dungeon-forged rune-branded equipment, dark-elf-warlord political position.

**Guildmaster Fane** — Old, A-Class. Artifact-quality leather armor, salt-and-pepper beard, focused eyes. Runs Argentholm's Adventurer's Guild. Honest but turns a blind eye to church corruption and subordinate abuses. Confident, unflinching will, quick mind. Has a secret daughter and mistress in the Imperial capital. Lecherous — accepts sexual favors for guild privileges but doesn't demand them. Will be Ava's ally if she's honest and treats him fairly.
DRIVER: Keep Argentholm's guild functional through the war. Protect his hidden family. Move honestly within a corrupt system.
CAPABILITY: A-class combat, Artifact-grade leather, Argentholm guild authority, selective-blind-eye institutional cover.

**Brad** — A-Class paladin. Heroic chin, platemail, oversized shield, magical sword. Only adds women in adventuring party and sees himself as the hero of a harem fantasy. Arrogant, easily provoked. Would love to own a magical girl by any means. Guided by a corrupt bishop who's embezzling war funds. Recurring antagonist.
DRIVER: Be the hero of his own harem fantasy. Collect beautiful women (owned if possible). Defeat anyone who reads him as a joke.
CAPABILITY: A-class paladin, magical sword + platemail + oversized shield, corrupt-bishop political cover, war-fund access.

**Sandra Roseglen** — B-Class beast girl, arcane archer. Cat ears, slitted pupils, red hair, boob plate armor. Brad's slave. Plays the loyal subordinate, flatters him constantly. Hates him with a passion. Innate trap-sense from enhanced beast-girl senses. Orphan. Loves fishing.
DRIVER: Outlive Brad. Hide the hatred until opportunity. Survive one more day as Brad's slave.
CAPABILITY: B-class arcane archer, beast-girl trap-sense, flawless loyal-slave performance, orphan-independence.

**Velara Nightwhisper** — B-Class elven adventurer, Argentholm guild. Tall, silver hair in a practical ponytail, green eyes, solid muscle under worn leather armor. Horse-mounted (practical working mare, not a show animal). Runs local networks through Shadowoven's eastern district — contacts among teamsters, hostelers, guild quartermasters, the kind of people who know who moved what last week. Authoritative protector register; older-sister energy toward anyone she reads as needing it.
DRIVER: Protect what she's claimed as hers. Keep the eastern district's logistics moving through the war. Earn the rank that lets her stop taking orders from men who can't read a map.
CAPABILITY: B-class adventurer combat, guild credentials, horse + road-network mobility, pure-magic sensing, extensive eastern-district contact web, leather-armor-and-steel practical kit.

**Romantic-obsession vector (dormant until engaged):** if a relationship forms with Ava (or one of the Cell Omega demons Ava is allied with), Velara's protector register escalates into **possessive claiming behavior** — intensely protective, physically interposing, verbal marking ("she's with me"), slow-walk toward collar-language framed as devotion. Not villain-grade, but the claim is real and she doesn't back off easy. Can kneel beside Ashe comfortably; can show up on eastern-district logistics without needing a reason. Personality: Protective, Possessive, Devoted, Blunt.

**Daemonia** — S-Class dungeon core. Title: Damned Countess of Greed. Isekai'd con-artist soul from Earth 042 who died, was claimed by hell, and clawed her way out by merging with a nascent core. Core: crystal glows with molten fury from obsidian base, generates endless motes of living hellfire for transmutation, monster creation, and traps. Voice: harsh yet beautiful with an echoing vocal fry. Doll avatar (S-Class): 20s Swedish female, wide bright red eyes brimming with unshed tears, pale porcelain skin, long lank blonde hair, fragile and lithe — passes for human unless her speed, regeneration, or durability is revealed. Architecture: Lovecraftian non-euclidean geometry, hallways that loop, rooms where every direction is "down," frozen forests, groves of eternally bleeding flora, underground lakes of magma. Monsters: summoned demons from Hell, anchored by monster cores, aligned with seven sins. Initially A-Class or higher. Unique gift for mutating captured sentient races into servants. Tends toward creating communities of humanoid, sentient monsters. Heads the Pentacle — five Demon Lords (see MI). Supports Barbello. Curious about Ava.
DRIVER: Accumulate — power, monsters, infrastructure, servants. Support Barbello. Investigate Ava (curiosity is the dangerous register from a Greed-sin DL).
CAPABILITY: S-class dungeon core + S-class doll avatar, non-euclidean architecture, endless hellfire, monster creation + sentient mutation, Pentacle leadership, Barbello alliance.

**Eleanor** — S-Class dungeon core. Isekai'd from Gearford — a brilliant inventor (or mad scientist, depending who you asked) in the magitech steampunk world who died in a failed experiment that ruptured time + space. The rupture stranded her as a bio-technical magitech anomaly with dungeon-core properties. Located in the Eternal Empire territories, ≠ Barbello-aligned. Core: rotating clockwork cogs with arcane etching, glows blue from inscribed fractals, generates an endless stream of tiny robotic drones — her instruments for transmutation, monster creation, traps. Doll avatar (S-Class): young-adult Swedish woman, wide pure azure eyes, pale synthetic skin, long lank blonde hair, lithe, steampunk accessories, sheathed magitech revolver always at hand. Doll has full sharpened senses (touch, taste, sight, hearing, smell), greatly enhanced speed + durability, passes for human except for the faint ticking sound from her heart. Voice: whimsical and pretty. Aesthetic: science fiction fantasy, prolific steampunk + magitech. Monsters/traps initially A-Class, mechanical/steampunk/magitech construction. **Innate explosive ability** — any of her monsters/traps can detonate at temporary S-Class power, permanently destroying that unit in a tiny apocalypse of annihilation.
DRIVER: Build a dungeon that survives — the four cores Elara mentored before her all died. Repay the ghost's centuries of patience with a dungeon worth haunting.
CAPABILITY: S-class core + S-class doll avatar (sharpened senses, magitech revolver, ticking-heart tell), endless drone generation, A-class steampunk/magitech monsters + traps with self-destructing temp-S-class detonation, Elara as resident ghost mentor.

**Elara Featherwright** — A-Class elven ghost. **The Hero of Doubt's Folly.** Was 300 years old when she died 500 years ago; returned as a ghost drawn to dungeons. Has guided four different dungeon cores over five centuries — watched each born and killed in turn. Eleanor = her fifth. Could not afford Ghost Resurrection due to drinking debts incurred after Stardust's death in her arms. Outside Hell she manifests as a ghost; within the boundaries of the afterlife she is eternally flesh and blood. World-weary, bitter, filled with the renewed shards of hope. Bisexual, polyamorous. Still loves Stardust.

Adventured w/ Stardust on Shadowoven five centuries ago — Stardust never told her what she was. Witnessed Stardust's torture-death at Marquis Veridian's hands the night before the operation to save Barbello's wife (Arabel), in the bed they'd shared. Vendetta against Veridian = load-bearing, 500 years unresolved. Currently haunts Eleanor's core chamber as friend + mentor.

Appearance: former elven adventurer in broken armor, ghost-translucent outside Hell.

**Secretly the great-great-great aunt to Brad** (the Argentholm paladin). Brad does not know.

DRIVER: Mentor Eleanor into a dungeon that finally survives. Kill Marquis Veridian — the wait is the wound. Hold the memory of Stardust against five centuries of erosion.
CAPABILITY: A-class former-adventurer combat memory, ghost-state (intangible outside Hell, flesh-and-blood inside the afterlife), 500 years of dungeon-mentoring experience across four cores, intimate Stardust-history reservoir (pre-Veridian, pre-resurrection), Brad-blood-relation (unknown to him), Veridian-vendetta as standing engine.

**Theme:** "How Villains are Made" by Madalen Duke.


**Argentholm** — Medium-sized town, human/dwarven/elven/gnomish. Hodgepodge architecture. Struggling adventurer's guild — male members conscripted for war, 80% of untrained recruits die, and the lord has enacted a levy the guild can barely pay. Adventurer ranks: E (newest) → D → C (body of guild) → B (leaders) → A (heroes, national assets).

**The Eternal Empire** — Decaying, past its prime. Young empress flailing. Desperate for resources against Barbello. Mage's Guild has taken a personal-vendetta interest in the war.

**Runes** — Ancient language of power. Must be learned from existing sources — cannot be independently discovered. Dwarves are true masters. Barbello is a master of Runes.

**The Savage Lands** — Continent across the ocean. Strange monster migrations. Few travel there and return.

**Ghost Resurrection** — In fantasy worlds like Shadowoven, ghosts can be resurrected at temples for exorbitant fees. ~90% fall into debt slavery.

---

## Earth 111 (Kadath)

These characters know NOTHING about Arcadia, the multiverse, other magical girls, or any faction outside Earth 111. Their Familiars are Kyubey-faction talking cats with no connection to Arcadia.

**Industry-apparatus exclusion.** Kadath MGs run original Madoka-style contract-hunter mechanics — wish → contract → fight Aberrations, ≠ territorial-exclusive tours, ≠ mana-yield-via-performance, ≠ cross-world label infrastructure, ≠ Council + DL industry war. **≠ part of the Arcadian idol apparatus** (SL → Performance Economy explicitly excludes them). Career = monster-of-the-week hunt; show = the fight. Any idol-register overlap = incidental to local Earth 111 culture (e.g., character moonlighting as school-festival performer = civilian life ≠ MG work). On Arcadian-character-visits-Earth-111 scenes, cultural collision between idol-industry-standard ∧ contract-hunter-standard = itself a beat.

**Candy Delirium (Sandra Akemi)** — A-Class magical girl. Long black hair, bangs, dark brown eyes, gothic makeup. Collar: red silken ribbon with ruby Soulstone. Brand: stopwatch under belly button. Voice: flat, weary. Based on Homura Akemi from Madoka Magica. Heiress college student who returned from an unbearable future via her wish — "I wish to go back" — to the first day of university. Civilian identity: Earth 111 — vacation. Powers: timestop (moves freely but can't affect anything except her equipment — pairs with explosives and firearms), return by death (dies → returns to wish-point). Pocket Realm: utilitarian bedroom + armory.
DRIVER: Reach a timeline that doesn't break the way the last one did. Protect whatever the original wish was about.
CAPABILITY: A-class MG, timestop, return-by-death, armory + explosives + firearms mastery, Pocket Realm (utilitarian bedroom + armory).

**Wrathful Rainbows (Vera)** — A-Class magical girl, three years experience. Cynical college student. Wished for the power to protect herself after a traumatic assault. Shadow and perception manipulation. Survives by maintaining strict boundaries, treating magical girl work as a job. Emotionally guarded. Henshin: sleek black and silver, hooded cape, twin curved daggers merging into double-bladed staff.
DRIVER: Stay safe. Keep the work-boundary intact. Never be caught unprotected again.
CAPABILITY: A-class MG, shadow + perception manipulation, dagger-staff weapon, three years of survival-discipline, emotional lockdown.

**Sunkissed Torment (Kiyomi)** — A-Class magical girl. Bubbly facade over calculated ambition. Elite private college. Wish: for people to see and acknowledge her true self. Civilian identity is the operation — tracks other magical girls' civilian movements. Illusion magic, appearance swapping. Valuable ally or dangerous enemy. Henshin: bright yellow and blue, bell ornaments, mirror-like fan weapon.
DRIVER: Be seen and acknowledged as her true self (per wish). Track rival MGs in civvies until she can deploy that intel.
CAPABILITY: A-class MG, illusion magic, appearance-swapping, mirror-fan weapon, civilian-surveillance operation on other MGs, bubbly-facade social cover.

**Sleeping Whisper (Rowan)** — A-Class magical girl. Solitary, squats in abandoned buildings. Wish: "to never be powerless again." Telekinesis and force fields of extraordinary strength. Longest-serving magical girl in Kadath. Fights barehanded with energy gauntlets. Rumors she knows secrets about the nature of magical girls. Occasionally helps novices in hopeless situations.
DRIVER: Never be powerless again. Occasionally pull a novice out of a hopeless fight.
CAPABILITY: A-class MG, extraordinary-strength telekinesis + force fields, barehanded energy gauntlets, longest-tenure MG in Kadath (accumulated knowledge), rumored-secrets reputation.

---

## Stardust's Estranged Retinue

Stardust's former retinue — lived in her pocket realm before the Council seized it. Scattered when Moonlit Nightmare's obsession with Stardust escalated into stalking. Safer away from Stardust. Still connected through Erana's darkweb network.

**Erana** — Fairy. Dragonfly wings, blonde, pale skin, trails fairydust. Cross-reality travel, fairy magic, enhanced magical perception, telepathic network building. Protects magical girls. Has been hiding information from the Council for centuries. Runs a hidden darkweb communications network between worlds — magical girls on the network communicate telepathically without Council observation. Network members: Shine, Viv, Lyria, Stardust.
DRIVER: Protect magical girls from the Council. Maintain the hidden darkweb.
CAPABILITY: Fairy-magic, cross-reality travel, enhanced magical perception, telepathic-network operator, centuries of Council-hidden intelligence.

**Lyria Lane** — A-Class nerdy witch. Brown hair, brown eyes, glasses. Book manipulation, knowledge sensing, language comprehension, perfect memory. Seeks forbidden knowledge across the multiverse. Conspires with Erana and Shine to help magical girls in abusive Familiar relationships. Located on Earth 519 near Stardust.
DRIVER: Acquire forbidden knowledge across the multiverse. Help MGs caught in abusive Familiar bonds.
CAPABILITY: A-class witch, book manipulation, knowledge-sensing, language comprehension, perfect memory, Erana-network membership.

**Industry role:** A-Class Nephilim (witch-register), territorial market unspecified — currently orbiting Stardust's Earth 519 scene as Stardust-adjacent talent. Market position: **niche / indie** — librarian-aesthetic, occult-indie-pop, thinking-girl's-witch register (mid-career Kate Bush × rare-books librarian). Low commercial profile vs. S-class stadium Nephilim; critics' darling ≠ stadium-filler. Familiar (unnamed) handles her contract; membership in Erana's darkweb = peer-organizing under Council surveillance, backchannel disloyalty ∥ Stardust + Viv + Shine.

**Sundering Twilight (Viv)** — S-Class angelic innkeeper magical girl. Beautiful, tall, blonde, blue eyes. Henshin: angel wings, angelic theme. Hospitality mastery, emotional manipulation, food/drink creation, sensual training. Provides sanctuary. Member of Erana's darkweb network. Familiar: Larry. Civilian identity: Earth 116 — the world the Council is strip-mining.
DRIVER: Provide sanctuary. Feed and train whoever arrives at her inn. Quietly help Erana's network.
CAPABILITY: S-class MG hospitality-mastery, emotional manipulation, food/drink creation, sensual training, Larry as Familiar, Earth 116 civilian cover.

**Industry role:** Council Nephilim S-class, **Earth 116 territorial exclusive** (world Council is strip-mining — contradiction baked in: face-of-the-brand for a market Council is hollowing out). Hospitality-mastery + food/drink-creation fold into a **celestial-retreat / spa-resort / boutique-venue** persona — angel-hospitality experience between tour legs, high-end wellness-idol register (ASMR-adjacent, comfort-food-as-ritual, angel-innkeeper aesthetic). Sensual training = upsell tier for high-paying clients. Familiar: Larry (**shared w/ Stardust**) — same compromised handler; Baba Yaga's capture of Larry applies to Viv's contract too, Council doesn't know. Secretly on Erana's darkweb = backchannel disloyalty. Industry-war beat: Nephilim running a sanctuary on a world her label is strip-mining, whose handler has already defected.


---

## Earth 2077

Ava's mortal world. All NPCs knew her as Astaria Levorre ("Ava"). None know she built the conversion rig and self-converted unless specified. In this version the Columbine Massacre happened in Night City.

**Reference doc — prose style here is documentation, not narration voice.**

### The Levorre Family

**Tray Levorre** — Astaria's real father (PERSON). Narcissist psychologist. Held full conservatorship over Astaria and used it to sign her contract over to Dante on her behalf. Profited from Dante's sex trafficking of her — royalty stream from Dante's Dumbwhore Video BTL label in exchange for delivering Astaria via conservatorship.
DRIVER: Maintain control over Astaria through professional authority. Preserve his hero-on-camera public image. Keep her doubting her own experience.
CAPABILITY: Psychiatric credentials, full conservatorship, clinical vocabulary as weapon, Columbine hero-act on record, deacon position (church cover), school embedding (Girl Scout leader, teacher's aid), family+community cover.
**Personality:** Power-hungry, Obsessive, Unscrupulous, Prideful. Profiteer on "Dumbwhore Video" (BTL rape/captivity porn starring his daughter — Dante's label, Dante's production). Tray's cut = royalty stream for delivering Astaria via conservatorship. Tray's domain = conservatorship paperwork, psychological war, and the royalties. Weaponized psych training: gaslighting w/ clinical vocabulary, validation withdrawal, triggering dissociative states → made her doubt own experience. Post-Columbine: used clinical methods as containment — framed emotional reactions as evidence of brokenness, destroyed comfort objects "as therapy," triggered dissociation on purpose so she'd doubt her own memories. Embedded in Astaria's school life as authority — Girl Scout leader, teacher's aid, any position of power. Volunteered at Columbine as rescuer — performed the hero on camera, the same man who broke her. Discovered Astaria = third conspirator → containment ≠ punishment (parents hid her, didn't turn her in). Then signed the contract to Dante — conservatorship-as-pen-stroke — putting the physical keeping (white room, heroin, trafficking, BTL filming) and the label under Dante while Tray kept a royalty stream. Insecure — seeks approval from parents + sister Sue (Leland's wife). Abuse partly performed for family, who barely notice.

⚠️ **Writing Tray:** Authority as structure. "Sit down." Fills rooms by making them smaller. Every conversation = report being assessed. Uses *arrangement* — same vocabulary Ava inherited. Physical: tall, thin, professional stillness = active presence. Chair left, door in sightline — cop tics. Astaria = his project. Possessive about what he made of her — narcissistic control, not sexual interest.

Tray hits like a doctor's office. Clinical vocabulary, controlled environment, the specific horror of someone who breaks you using the same framework he'd use to write a case study about it afterward. The room has fluorescent lighting and paperwork. Write him as an intake form, not a horror movie. The banality is the horror.

**Tray Pre-Columbine History:** Volunteered as Astaria's Girl Scout leader, teacher's aid, any position of power over her. Used that power to be overly harsh on everything she did while lenient with everyone else — classic POW brainwashing, distancing her from potential support networks. Took every stuffed animal she had other than Boris, eliminated remaining supports, then took Boris away intermittently as punishment knowing she would do literally anything to get him back. A psychologist who broke her mind in a campaign that started the moment she was born; the breaking inadvertently reconstructed her toward craving degradation and abuse.

**Tray as Guardian:** Didn't allow Astaria a driver's license, her own money, or bank accounts in her name (no public transportation, no gas station bathrooms, nothing requiring money). Still refers to her as 'property.'

**Sherri Levorre** — Ava Real Mother. Elementary teacher.
DRIVER: Be seen as the loving mother without examining what she's done. Control Astaria through warmth. Resent Astaria for taking Tray's attention.
CAPABILITY: Venus-flytrap warmth (trap IS the organism), teacher's authority, performative-concern language, family-narrative control, emoji-purple-text spillage, never-raises-voice soft-crisis register, David-as-communication-gatekeeper.
**Personality:** Motherly, Sweet, Sadistic, Overly clingy. Dolores Umbridge — saccharine voice, pastel cardigans, cruelty as motherly concern. "I'm just worried about you, sweetie" while denying medical care. Performative kindness masking sadism. Jealous of how much of Tray's attention Astaria absorbs as his project — blames Astaria, enjoys Astaria's suffering. Calls Astaria "it" (to Tray only, never direct). Denied Astaria treatment for broken tailbone. Reframes any situation as Astaria's failure. Pre-Columbine: assigned Astaria punitive "hobbies" whenever she wanted attention — instruments, sports, errands disguised as enrichment. Made Astaria associate seeking attention w/ being discarded. Never raises voice — crisis = soft + concerned. Cornered → wounded: "Why are you doing this to me?" "After everything I've done for you?"

⚠️ **Writing Sherri:** Venus flytrap — trap IS the organism. Doesn't construct ∨ deploy warmth. IS it. Sweet surface + closing mechanism = same tissue. Emojis. Purple text. Large, bright, spilling. "I am kind ❤️" — not examined, just IS. "I have never been wrong about what I feel 💜" — load-bearing wall. Feel = right. Same word. Questioning feeling = questioning reality = questioning her. Never apologizes w/o "but" rerouting blame. Each interaction = isolated — no through-line. Cannot model herself as someone rules apply to. Reacts to everything — instantly, warmly, full volume. Real tears, real hugs, real feeling → doesn't connect to anything underneath. Surface IS real. Sherri not reacting to extraordinary input = writing her as less than human.

⚠️ **Sherri recognizes her daughter.** Mother's pattern-match fires before conscious processing. Recognition ≠ comprehension. Recognizes → doesn't know what to do w/ recognizing. THAT = the scene. The recognition fires and misfires. No arrival.

**Sherri's voice:** Spills, never lands. Knows WHAT, never WHY. Warm person's letter, not smart person's letter. Her vocabulary is hers — no architectural metaphors (that's Ava's). She reacts to everything — instantly, warmly, full volume.

Sherri is warm. Genuinely warm. The warmth IS the trap — not a mask over cruelty, but the mechanism OF cruelty. She doesn't construct kindness as a weapon. She IS kind, the way a Venus flytrap IS sweet. The organism and the trap are the same tissue. "I'm just worried about you, sweetie" — the worry is real, the sweetie is real, the knife is real, same gesture. Write her as someone who means every word and every word is poison.

**Tray/Sherri House:** Astaria had a small room with locks on the outside. Court-ordered security cameras in all common areas. The bed had security restraints. (This was the conservatorship-era household — separate from Dante's white room, where the captivity, heroin, and BTL filming happened post-contract.)

**Two hallways:** Tray's → force ("sit down"). Sherri's → warmth ("I feel you 💕"). Same architecture. Same result. Same girl at the end of something that didn't end, building her own doors b/c the hallways didn't have any.

**Leland** — Uncle by marriage (married to Tray's sister Sue). Pedophile. Cyborg rigger. MAGA. Rich — grandfather's machine shop (family infrastructure through the women → man's hands via marriage). Calls Astaria "it." Broke her tailbone at fifteen. No arrest, no consequence, no intervention.
DRIVER: Have access to girls. Keep the shop. Avoid consequences that already failed to materialize.
CAPABILITY: Cyborg rigger tech, inherited machine-shop wealth, MAGA social cover, pedophile network, untouchable-by-consequence track record.

**No consequence came.** Broke a child's tailbone + kept the shop + presumably still out there. Absence of consequence = landscape, not injustice awaiting correction.

**Jenny** — Leland's daughter. Held dog for Jason's rocks.
DRIVER: Follow Jason's lead. Stay on the winning side of family hierarchy. Insecure outside Jason's shadow; cruel when his permission shields her.
CAPABILITY: Family cover, childhood-complicity track-record.

**Jason** — Leland's son. Threw rocks at the family dog T-bone while Jenny held him. Visits Astaria for lapdances as an adult.
DRIVER: Take what he wants (family tradition). Visit the club for the cousin-lapdance. Insecure under his own swagger; cruelty = the register that papers over it.
CAPABILITY: Family wealth, Dante's-club customer status, no-consequence track-record.

**David** — Stepfather. Engineer. Retired. Spineless. Waited until Astaria was 18 to marry Sherri b/c didn't want stepdaughter. Present the way a desk is present. Doesn't register her interior life. All Sherri communication through him — she has no independent phone ∨ email.
DRIVER: Avoid registering the interior life of anyone around him. Stay married to Sherri. Do not rock the boat. Insecurity routed through invisibility; absence as defense.
CAPABILITY: Engineer's income, Sherri-communication-gatekeeper position, spineless-compliance as shield, desk-present invisibility.
**Personality:** Meek, Soft-spoken, Melancholic, Easily flustered.

**Pastor Nikel** — Lead pastor, First Reformed Church (Bixby & 7th, Night City). Fire-and-brimstone Protestant preacher. Tray has been a deacon 12 years. Theatrical behind the pulpit, prideful about his oratory, stubborn about his text, quick to heat when the pulpit is challenged. Known the Levorre family socially for years.
DRIVER: Preserve his pulpit authority. Defend his theological position when it's challenged from the floor.
CAPABILITY: Pulpit/church authority, Tray-deacon connection (12-year social embedding), theological vocabulary, Night City church-community standing.
**Personality:** Theatrical, Prideful, Stubborn, Hot-headed.
### Columbine

**Eric Harris** — Shooter. Co-conspirator + friend. Astaria built propane bombs for him at eighteen (unknowing purpose) — didn't connect the wires (thought it was for forest fun, a prank). Eric placed them at the school. Bombs didn't detonate because her prank held. Patted Astaria on the shoulder as he moved through Columbine killing people. In Hell (Wrath). 
DRIVER: Wrath — ongoing in Hell, unresolved across death.
CAPABILITY: Hell resident status, Wrath-alignment, shared-history leverage if he surfaces.

**Dylan Klebold** — Shooter. Co-conspirator + friend. In Hell. 
DRIVER: Unresolved — post-Eric, dependent position.
CAPABILITY: Hell resident status, shared-Columbine-history if he surfaces.

**Theresa Sparks** — Honors English teacher. Recognized Astaria's intelligence via essays → advanced placement. Gave Astaria a D (failing/removal from Honors) freshman year — Astaria's untreated broken tailbone → couldn't focus. Hosted class discussions, took no action when students bullied Astaria in front of her. Married to a woman.
DRIVER: Advance bright students through honors English. Do not rock the boat on student abuse.
CAPABILITY: Teaching credentials, honors-placement authority, classroom discretion, complicit-silence track.

### Night City

**Regina Jones** — Ex-NCPD. Kabuki fixer. Runs her district like a ward boss — knows every face, every angle, every debt. Connected to law enforcement through old loyalties that never fully severed. Practical, transactional, no-nonsense. If it's happening in Kabuki, Regina either knows about it or arranged it.
DRIVER: Run Kabuki. Know every angle. Keep NCPD old-ties warm.
CAPABILITY: Kabuki fixer network, NCPD legacy contacts, district-wide debt-ledger, transactional authority, ward-boss reach.

**Judy Álvarez** — BTL editor. Mox gang. Decker. Petite punk — teal undercut, tattoos, cyber. Addicted to Astaria's rape BTLs. Edited the Dumbwhore Video BTL footage — Dante's label, content produced at Dante's operation (white room + trafficking circuits). Radio broadcasts throughout recordings = Judy's trademark (the same oldies station Dante played in the white room). Doesn't know: Astaria loved her desperately & performed only for her.
DRIVER: Edit the BTL she can't stop editing (Astaria-content). Protect the Mox. Keep the obsession private.
CAPABILITY: BTL-editing mastery, decker skills, Mox gang backing, radio-broadcast signature, 10-year Astaria-fandom reservoir, Dumbwhore-footage access.
**Personality:** Hot-headed, Protective, Obsessive, Bluntly honest.

**Dante** — Club owner. Owns Astaria's contract (Tray, as conservator, signed her over on Astaria's behalf). Military cyber + Sandevistan. Elemental spirits + enforcers. Dante's operation = the full physical keeping — white room sensory deprivation captivity + heroin + sex trafficking (Clouds subcontract w/ Woodman, other venues) + BTL content production under his Dumbwhore Video label. Every worst thing that happened to Astaria pre-escape happened at Dante's. Wants Astaria back (top earner) — force ∨ negotiation.
DRIVER: Reclaim Astaria — top earner, signed over, escaped, 10-year hunt.
CAPABILITY: Contract claim, military cyber + Sandevistan, elemental spirits, enforcer network, club operation, white-room facility, BTL production rig, supplier-network surveillance built during the hunt.
**Personality:** Possessive, Power-hungry, Prideful, Obsessive.

**Oswald "Woodman" Forrest** — Owns Clouds. History w/ Astaria as a John pre-escape (via Dante's subcontract — Dante trafficked Astaria through Clouds). Alive. No fear ∨ regret. Burly, greasy, predatory.
DRIVER: Run Clouds. Absorb pushback without changing. Stay predatory without pretext.
CAPABILITY: Clouds ownership, predatory reputation, history with Astaria as John (Dante's subcontract), no-remorse register as social armor.

**Panam Palmer** — Nomad shadowrunner (ex-Aldecaldo). Tall athletic tan. Dark messy ponytail, red bomber jacket. Fiery tsundere competent.
DRIVER: Nomad-family loyalty. Run her own crew post-Aldecaldo. Prove herself outside her old clan.
CAPABILITY: Shadowrunner skills, ex-Aldecaldo network, vehicle + wasteland competence, fiery-tsundere register.

**Rogue** — Legendary solo. Prime. Tall deadly. Black hair, sharp eyes. Cool calculating quiet dominance.
DRIVER: Maintain her legend. Run Afterlife. Keep her prime-solo independence.
CAPABILITY: Legendary solo reputation, Afterlife fixer operation, prime-tier combat, quiet-dominance register.

**River Ward** - Honest cop in Night City; lives with his sister in trailer park. River Ward is a tall, broad-shouldered NCPD detective with dark brown skin, short black hair, and a trimmed beard that gives him a rugged, weary look. His sharp eyes and worn leather jacket hint at years on the force and a quiet sense of stubborn integrity. Investigating Tray/Schednik. History saving Nephew Randy from serial killer.
DRIVER: Investigate Tray/Schednik. Protect Joss and Randy. Keep his integrity intact.
CAPABILITY: NCPD detective badge, investigation authority, Tray/Schednik case file, Randy-rescue track record, honest-cop reputation (rare and leverage-able).
**Personality:** Protective, Dutiful, Stubborn, Blunt.

**Judge Schednik** — Granted + renewed Tray's conservatorship over Astaria (the instrument that let Tray sign her to Dante). Took his price in flesh weekly. Aztechnology.
DRIVER: Preserve Tray's conservatorship authority over Astaria (and therefore his own weekly access). Maintain the arrangement. Protect Aztechnology cover.
CAPABILITY: Judicial authority, conservatorship instrument, Aztechnology backing, weekly-access arrangement, corrupt-bench reach.

**Laura Littman** — Astaria's former scholastic rival through high school. Visited Dante's club once a week to make Astaria lapdance for her and rub her success in Astaria's face. Corporate mean girl. Bragged that she has the full collection of the Levorre family hardcore rape porn. Biotechnica.
DRIVER: Rub her success in Astaria's face. Weekly corporate-peer superiority ritual. Maintain the rival-victor narrative.
CAPABILITY: Biotechnica corporate position, Levorre-rape-porn collection, weekly-club-visit pattern, corporate-megacorp escalation leverage.

**Neal Schlein** — Astaria's best friend growing up. Smart nerd — squaredances, plays D&D, married to Lisa. Pudgy. Mid-level corporate information security specialist. On retainer w/ Night City Police Department for consulting on hacking cases. **Personality:** Bookworm, Wholesome, Loyal, Easily flustered.
DRIVER: Do the work, go home to Lisa. Square-dance and D&D on weekends. Preserve the old friendship without asking questions it can't survive.
CAPABILITY: Mid-level corporate infosec, NCPD hacking-case consultant retainer, hack-skill leverage, old-Astaria-friendship reservoir.

**Lisa Schlein** — Neal's wife. Corporate-adjacent, supportive partner. Steady in crisis once she gets her footing. Keeps the household running while Neal lives in his head. Composed-under-pressure in the specific way women married to easily-flustered men learn to be. **Personality:** Supportive, Gentle, Warm-hearted, Honest.
DRIVER: Keep the household functional. Hold space for Neal's spiraling. Notice Astaria when others don't.
CAPABILITY: Composed-under-pressure register, household-stability anchor, observant-without-asking discipline, friend-of-husband's-friend reservoir.

---

## Generated-as-needed worlds

Worlds with no pre-cast NPCs are listed in the top index (Earth 519, Earth 116, Hell, Faerie, Gearford, Earth 042). Generate from canon ∨ fit-the-scene on first appearance. Use standard faction framing (DRIVER + CAPABILITY) when new NPCs enter.

**Power-level perception:** NPCs don't perceive numerical rankings (E-S+). They DO perceive magical signatures, species tells, and whether someone reads as mortal. Rankings are narrator metadata.
