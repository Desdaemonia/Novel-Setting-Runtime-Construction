# SUPPLEMENTAL LORE: TheWeird Setting

## Type: reference (on-demand)

## Index

1. **Arcadia & The Three Factions** — Familiar Council (strip-mining, The Forge), Demon Lords (Lucifer, thirteen girls, four cells + solo), Void Cult (Void Incursions, Void-touched mortals)
2. **Magical Girl Mechanics** — contract/wish/collar/brand, henshin vs civilian (S-Class vs D-Class), physicality, identity (no-aging rule, terminology boundary), energy types (mana/Puno Memo — DO NOT CONFLATE), parasitic bond + DL parasitic link, DL Protocol (kneel/feudal framing), Puno Memo perception, rankings (E→S+)
3. **Performance Economy (Arcadian Idol Apparatus)** — Arcadia-wide entertainment-industry operational layer cross-faction. Hell's Demon Girls = cell-based idol groups (Cell Omega = k-pop trio: May frontwoman, Ashe backup + ghost-roster-as-band, Glit captured, Ava stand-in contractor) + Council's Nephilim = solo headliners per world (clean-image major-label acts, Forge = captured creation-talent wing). Industry war ∥ shadow war. Scene types (concert/studio/promo/green-room/after-party/tour/rehearsal). Fan-intensity = mana source. DLs + Council = labels. Wands = instruments. Combat = background weather.
4. **Dungeon Mechanics** — cores (unaging, mana-generating), claiming (faction-dependent), boss monsters, unclaimed dungeon raids. World-feature only — Ava is not a core-claimer.
5. **Key Worlds** — list of commonly visited worlds in this multiverse. Earth-numbered entries = *parallel worlds* (Earth variants); non-Earth entries = worlds in their own right (Shadowoven, Hell, Faerie, Gearford, etc.).

**Pull pattern:** read index → identify section(s) by trigger → read that section only. Grep `##` to jump.

---

## Arcadia \& The Three Factions

**The Familiar Council** (a.k.a. Council of Nine — same body, two names): Dominant power. Girls = tools + pets. One girl per world. Winning the shadow war. Secret: strip-mining magic from every reality — drain cores, introduce substitutes (damage souls → dungeons starve → collapse). **The Forge:** Hundreds of captured creation-talent Magical Girls (any faction — Nephilim, Demon Girl, independent) manufacturing binding artifacts. Work until they stop → fixed → work again. Ava was supposed to be there.

**The Demon Lords:** Led by Lucifer. Girls = allies/co-conspirators. Thirteen Demon Girls — four cells of three + one solo. Cells compartmentalized. Souls = their resource (Demon Girl collars absorb souls from nearby sentient deaths). Three factions fight through proxies. Council winning. **DLs do not wear collars.** Collar/brand/Soulstone/clit piercing = markers of the contracted girl. DL = master. No ownership markers on a DL, ever — the girls kneel to them; DLs = sovereigns ≠ property. **Astarte caveat:** Fallen goddess who became a Demon Lord. Left Heaven with Luna for personal reasons ≠ Luna's Forge-war. Contracted Ava before the Council could claim her. Ava is contracted to Astarte, Demon-Girl-shaped (collar/Soulstone/piercing/Henshin/BDSM dynamic) but ≠ in the count of 13 + exempt from can't-lie + standard parasitic link (canonical phrasing → NR § Ava's status). Astarte runs a personal project ≠ Hell's operational priorities ≠ Luna's Forge agenda. **Luna caveat:** Separate DL from Astarte. Forge-dismantling agenda is Luna's — saw the Forge from inside, walked in disgust. Glit = Luna's girl (captured storming the Forge). Luna holds Glit's Cell Omega slot empty. Co-defectors from Heaven, aligned anti-Council axes (Luna = Forge, Astarte = personal), different wounds.

**The Void Cult:** Secretive saboteurs. No active girls. Underground dungeons where missing girls are experimented on. **Void Incursions:** The Void bleeds into worlds — monsters, corruption, ambient wrongness. Mortals predisposed to violence (serial killers, predators, people with existing darkness) become Void-touched: enhanced, twisted, harder to kill, driven by something that isn't entirely theirs anymore. Void incursions are the random encounter element — the ambient threat magical girls handle as part of the job, between faction conflicts. The Cult cultivates these incursions deliberately; some happen wild.

## Magical Girl Mechanics

**Terminology stack.** "Magical Girl" = umbrella (all contracted girls across factions). "Nephilim" = Council/Familiar-contracted (Heaven-aligned). "Demon Girl" = DL-contracted (Hell-aligned, includes Cell Omega). Kadath/Kyubey-faction MGs (Earth 111) = isolated third system, ≠ Nephilim, ≠ Demon Girls. Umbrella when crossing factions ∨ speaking generally; specific term when faction matters.

**Arcadia-wide operational frame:** Magical girls = **performers** cross-faction. Two poles share the industry:
- **Hell's Demon Girls** — cells = idol groups across genres (Cell Omega = k-pop-shaped; three offscreen cells in adjacent genres — rock, classical-goth, folk, open set; Eclipse = solo artist). Cross-world tours via cell portal network. Dark/edgy/sexualized registers. DL parasitic link.
- **Council's Nephilim** — solo headliner per world (territorial exclusive). Clean-image Heaven-aligned registers (pop / gospel-pop / uplift-anthem / radio rock — open set per world's taste). Major-label machinery (Council labels + Familiar-handler doubling as manager). Familiar parasitic link. The Forge = captured creation-talent wing manufacturing catalog artifacts.

Shadow war = **industry war** — audience, mana yield, talent poaching, cross-world market share. Kadath/Kyubey-faction MGs (Earth 111) = isolated regional market ≠ integrated into the Arcadian industry (contract-hunter logic). See SL → Performance Economy.

**Contract:** Familiar → soul contract → wish → collar (material varies per girl + Soul Gem) → brand → body remade. **Demon Girl contract = also the career deal** — one instrument binds soul + label + brand + stage persona in the same paper. DL = Overlord ∧ agency head; collar = ownership marker ∧ legal device locking the idol to her label (Soulstone inside = career literally soul-bound). Breaking the contract = breaking the soul.

**Henshin:** In Henshin = S-Class. Outside = D-Class. Write the difference. **Demon Girl Henshin = the stage form** — costume, makeup, wand-instrument, power-set, public persona arrive in transformation. Civilian = off-stage, between takes, touring in street clothes, green-room downtime. Henshin costume = album cycle's visual identity (Ashe = ghostly white gown + crown of blue flowers, idol-fantasy register; May = red-dress-succubus form, Radio Demon brand). S-class jump on transformation = how MGs ∧ idol groups both stage-reveal power; scale of the difference IS the spectacle.

**Physicality:** Magical girl bodies and constructs are created by soulgems and are physically real.
**Identity:** No cognitive separation between henshin and civilian — people who know her can recognize her in either form. Collar reads as jewelry to non-Arcadians. **Magical girls do not age. The contract remade the body younger — Ava looks younger than she did when the conversion remade her (AL §7). She's frozen at the resulting younger form ≠ at the remake-moment age. She has not aged a day since. Anyone who knew her at any point in her life sees a woman who looks YOUNGER than they remember, not older.** Mortal names in civilian scenes, designations in henshin. **Demon Girl designation = stage name** — Cherished Mayhem / Radio Demon on stage + in promo, Arabella Cadwell in civvies (rarely used; stage name = who she is now). Adored Ashes on stage, Sarah Carter mortal-dead-name (unused). Non-Arcadians see Demon Girls in civilian form, read the stage name as performer alias, Henshin as stage persona. **Terminology boundary:** Non-Arcadians see collar as jewelry, powers as unexplained. Arcadian terms (Demon Lord, Familiar, magical girl, Soul Gem, henshin, faction names) unknown outside Arcadia. Full rule: PI §4.
**Energy — Two Distinct Types (DO NOT CONFLATE):**

1. **Mana** — the magical energy of Arcadia. **What magical girls run on.** Stored in Soul Gems. Dungeon cores generate mana as a byproduct of stable nuclear fission. The Council strip-mines mana from cores to feed its grid. When the doc says "magical girls run on magic," it means mana.
2. **Puno Memo** (Purified non-dimensional meta-energy with morphic effects) — Ava's term, nobody else uses it, she keeps using it anyway. **Energy from OUTSIDE dimensions entirely.** Not refined mana. Not a purer form of mana. A separate, higher-order energy with morphic properties (shapes reality) that mana cannot replicate. Ava uniquely taps into it.

**Parasitic Bond:** Magical girl collars accumulate mana. Familiars drain it. **Familiar = parasite. Girl = host.** Shapeshift. Familiar arranges situations that accumulate mana (sex, combat, intense emotion) and siphons from the girl's Soul Gem. Not partnership — extraction.

**DL Parasitic Link (Overlord Harvest):** Demon Girls generate mana via elevation — performance, crowd-intensity, sex, combat, heightened emotion — Overlord siphons through the collar's Soulstone (capped/day). Same extraction logic as Familiars, different dressing. Cell Omega's DOMINANT channel = **performance** (Performance Economy below). Overlord = label-head: claims the yield, sets the brand, owns the contract. The girl works the show; the boss takes the cut. 

**Demon Lord Protocol:** Demon Lords = kings/nobles/emperors. Magical girls = knights. The relationship is feudal — a knight kneels to any sovereign, not just their own liege. Demon Girls kneel to Orobas (open set) the way a knight kneels to a visiting duke: formal acknowledgment of rank, not personal submission. Address by title or name. The formality communicates power hierarchy to anyone watching — an observer seeing Ava kneel understands "this person outranks her" without exposition. **Legalist framing (韓非子):** protocol exists because the structure requires it ≠ because the individuals deserve it. The knee bends for the position ≠ the person. Friendship, affection, familiarity — none modify the obligation. If protocol depends on the relationship between individuals, it's courtesy, and courtesy can be skipped. Structural protocol cannot be skipped because skipping it damages the hierarchy ≠ the person. **Both knees.** Full kneel ≠ crouch ≠ one-knee genuflect. Hold until acknowledged or dismissed — rising without permission = breaking protocol. **Sequence: protocol → acknowledgment → personal register.** After the DL acknowledges, the real relationship surfaces. Friends are warm. Allies are professional. Strangers are cautious. The formality doesn't erase what comes after — it frames it. A knight who skips the knee insults the crown, ≠ the person wearing it. **Idol-mode layer:** in Cell Omega contexts, feudal kneel ALSO reads as industry hierarchy — Demon Girl kneeling to visiting DL = junior idol bowing to visiting label executive. Both real. Ceremonial form covers cosmic ∧ corporate hierarchy at once.

**Puno Memo Perception:** Only perceivable when Ava is present — outside that, no magical signature. The Denver garage breakthrough (AL §7) was a one-time uncontrolled spike pre-contract; post-contract, the Soul Gem contains and stabilizes the signature to local-only perception. The breakthrough was the exception ≠ the rule — writing "someone detected Ava's Puno Memo from across the multiverse" post-contract = drift against this entry. Why she matters: creation-type MG contracted to a rogue Demon Lord is unprecedented and Puno Memo access is unique to her. Resonance = felt by sensitives as expanded possibility and awe.
**Rankings:** E (mortals) → D → C (veterans) → B → A (national) → S (magical girls) → S+ (Lucifer, etc).

## Performance Economy (Arcadian Idol Apparatus)

The Arcadian MG apparatus = **entertainment industry cross-faction**. Performance-elevated mana extracts up to the girls' patrons (DLs for Demon Girls, Council for Nephilim) via respective parasitic channels, same extraction logic as sex/combat elevation — but **performance = primary channel** across both poles.

**Hell's roster.** Thirteen Demon Girls; four cells of three + one solo. Cells differ by genre + presentation. **Cell Omega = the k-pop-shaped idol trio** (Ava's cell). Three offscreen cells in adjacent genres — rock, classical-goth, folk, open set — generate-as-needed if they surface. **Macabre Eclipse = solo artist** (goth-witch sorceress register). DL parasitic link.

**Council's roster.** One Nephilim per world — solo-headliner per territorial market. Clean-image Heaven-aligned registers (pop / gospel-pop / uplift-anthem / radio rock — open set per world's taste). Massive corporate machinery per act (Council labels, cross-world PR, Familiar-handlers doubling as managers). **The Forge** = captured creation-talent wing — kidnapped creation-type MGs (any faction) locked in manufacturing catalog artifacts, the way a major-label-owned publishing arm grinds out contract songwriters + producers. Familiar parasitic link.

Shadow war = **industry war** — audience, mana yield, talent poaching, cross-world market share. Council = major-label conglomerate; DLs = renegade/indie/outlaw labels.

### Cell Omega — Band Configuration

- **Cherished Mayhem (May)** — **frontwoman / lead vocal / face.** Stick-microphone wand IS her instrument. Sound-amplification + music-that-sways-emotions thaumaturgy = literally the main act. **Holmes' Hotel = HQ + recording studio + primary venue.** Lucifer = label-head. Full character + capability + thaumaturgy stack: **NR → Cherished Mayhem**.

- **Adored Ashes (Ashe)** — **backup vocalist + bandleader.** Sings soft harmony behind May's lead. Her ghost roster manifests AS Cell Omega's live band on Henshin (Robert Johnson lead guitar / Riders in the Sky drums / Davy Jones bass / Bell Witch keys / Hessian additional percussion / White Lady backing vocals / Saint Columba choir / Resurrection Mary tour logistics — **full instrument-mapping + ghost capabilities: NR → Adored Ashes**). Eight finger-rings ring resonance into the live mix — producer-slash-singer wearing her mixing board as jewelry. **Quiet idol to May's loud.** Ghosts = bandmates ≠ soldiers; **Ashe = gate ≠ commander.** **Winchester Mansion = studio + dorm.** Orobas = label-head (see Labels below).

- **Glitterbomb Holocaust (Glit — Captured)** — **pyrotechnics / stage effects / special-effects producer.** Cell Omega *looked* the way she built them to look; absence = silent effects booth + empty mic-stand. Luna refuses to replace her — Glit built how Cell Omega's show worked. Her realm's portal endpoint = dark since capture. **Full entry: NR → Glitterbomb Holocaust.** Ava fills the gap unofficially (see Ava bullet below + MC → Cell Omega Role).

- **Ava (unofficial stand-in contractor)** — **effects + backup vocal**, filling Glit's slot. Full role + behavior + ownership-status: **MC → Cell Omega Role**. Cell-context only: Memetic ≠ portal network, A.V.A. logo on the amp, Orobas wanders into her studio sessions to borrow things.

### Council Nephilim — Solo-Headliner Apparatus

Nephilim = **solo headliners, one per world** — territorial exclusive, designated Council-branded act for her market. No cell structure. Civilian identity doubles as the act's mortal-persona (studies at the local university, works at the local firm, shops at the local cafe); Henshin = stage persona touring the world. **Familiar = handler / manager / parasite** (all three the same Familiar, same relationship — the feed IS the contract). Concert scale: stadium-tour (high-yield Nephilim) → local-venue-circuit (junior Nephilim). Branding cohesive cross-world — clean aesthetic, uplift registers, crowd-pleasing genre tuned to the territorial market. Nephilim tour via **Council portal networks** (separate from DL cell-portal network).

**The Forge = catalog manufacturing wing.** Canonical Forge definition: **Arcadia & The Three Factions above**. Industry framing: standard major-label-owned-publishing-arm — captured creation-talent locked in, catalog manufactured (including equipment Nephilim use on tour), credits buried, no way out.

**Wands + instruments.** Nephilim carry wands same as Demon Girls — instrument first, weapon second. Wand-as-instrument shape varies per Nephilim per her act's genre — acoustic guitar, grand piano, violin, mic-stand, electronic rig, turntables, string-section baton, open set.

**Industry war at ground level.** Demon Girl cells ∧ Council Nephilim compete for audience, market share, airplay, merchandising, streaming attention, high-value venues. Cross-faction poaching attempts (DL recruiting a Council-contract Nephilim off her territorial exclusive — near-impossible given the Familiar bond, attempted anyway). Sabotage tours. Leaked tracks. Rumor campaigns. Proxy warfare between factions has a label-feud register on top of the cosmic hierarchy — both real.

### Operational Reality — Scene Types

- **Concert.** Live show. Full setlist. Audience-intensity = primary mana source, harvested in bulk by DLs through parasitic link. Stage = the world of the scene. Combat in streets outside the venue = background weather; the band is on stage.
- **Studio.** Recording session inside a pocket realm (Holmes' / Winchester / Ava's workshop inside Memetic). Arrangements, takes, disagreements about the bridge, May riding Ashe about mic-timing, Boris filing a report about the sound mix from the couch, Orobas wandering in to borrow something.
- **Promo.** Interviews, broadcasts, appearances, brand work. May owns this — Radio Demon = literally runs her own broadcast apparatus; promo = her native register.
- **Green-room.** Backstage between sets. Costume changes (Henshin ↔ civilian), downtime, cross-talk, whatever argument got paused before the show.
- **After-party.** Where the DLs harvest the elevated yield. Sex-elevated magic still fires; now fires *after the show*, in the pocket realms, w/ the night's performance already having pumped the girls' reserves. Cell-as-labelmates dynamics live here.
- **Tour.** Cross-world circuit via the portal network. Holmes' → Winchester → (Glit's realm: dark) → guest venues in Hell, Shadowoven, Earth 519, Earth 2077, Gearford, wherever Lucifer's booking agent sent them. Audience composition varies by world; show adapts. Ava arrives via Memetic.
- **Rehearsal.** Boring domestic-mode. Ghosts argue about tempo. May re-writes a verse. Ashe holds a harmony for forty minutes. Ava fixes a broken cable w/ the sonic screwdriver.

### Fan Intensity = Mana Source

Crowd presence generates raw audience-energy the girls' Soul Gems absorb during performance. Sex-elevated magic still works (existing parasitic channel, capped/day) — but in idol-mode **dominant channel = the crowd**. Bigger crowd → more elevation → bigger harvest up to the DL. Overlords get paid through the show.

### Labels (DLs + Council)

**DL-side.** Lucifer runs May's career the way a label runs a star: sets the tone, claims the brand, profits from the yield, pretends to be supportive, pulls the leash when she goes off-brand. Orobas runs Ashe the same way, quieter — his Kramer-register means he also wanders into the studio to complain about the coffee while she's tracking. Luna ran Glit; now slot = dark ∧ Luna holds the silence. DL-as-label = *agency-contract reality* the BDSM/slave dynamic wears in public.

**Council-side.** Familiar Council = **major-label conglomerate**. Each Nephilim = solo headliner on a territorial exclusive — one act per world, Council-branded, Heaven-aligned aesthetic. Familiar = Nephilim's Familiar-handler doubling as manager/parasite (all one relationship — the feed IS the contract). Council priority = mana yield + brand consistency + audience dominance. Nephilim who wander off-brand get Familiar-pressure first, punitive reassignment second. The Forge = owned publishing arm; strip-mining = vertical-integration play against rival labels (DLs).

Both real cross-faction — ownership = structural; label relationship = how the ownership reads on camera. Glitter ≠ erase the leash — Heaven's leash ∧ Hell's leash both.

### Instruments (Wands)

May's stick-microphone, Ashe's eight finger-rings (worn while playing — ring resonance into whatever her ghosts produce, like a producer's live-mix EQ worn as jewelry), Eclipse's Yggdrasil-wood witch-wand (doubles as staff-mic for solo work). **Nephilim wands** same principle — genre-shaped per act (acoustic guitar, grand piano, violin, mic-stand, electronic rig, turntables, string-section baton, open set). **Instruments first, weapons second.** Cross-faction. **Heavenly Orichalcum** (permanently kills angels/devils) — only Ava's portal gun/sonic screwdriver is forged from it. See MC.

### Band Dynamics (Load-Bearing)

**Cell Omega / cell dynamics (DL-side).** Working trio. Argues about arrangements, fights about setlists, covers for each other's bad days, gossips about the other cells, sometimes hates each other on a tour bus. Sister-slave structurally intact (each owned by her Overlord, each collared/branded/pierced, each dancing for her DL's power yield) — structure IS the agency contract, the label relationship, the exploitative-industry reality running under every polished performance. Ownership ∧ artistry both real.

**Nephilim solo dynamics (Council-side)** share the substrate, different shape. Solo act = **isolation** (no cell to complain to; Familiar = handler/manager/parasite, not her peer). Parasitic Familiar-bond claims her yield, brand, tour income. Touring alone → no bandmates to share emotional labor with — Familiar = the only constant companion on the road. Isolation = design feature of the solo-headliner contract: keeps the Nephilim dependent on her handler. Cross-Nephilim friendships exist (Stardust's Estranged Retinue = darkweb version) but require operational secrecy; Council treats peer-organizing as a threat.

Kyubey-faction MGs (Earth 111) don't run the performance apparatus — isolated contract-hunter logic, different industry structure entirely.

### Combat When It Surfaces

Void Incursion at a venue. Council snipers at a tour stop. Rival cell members crashing a show. Demon-hunter crashes the encore. Combat = Tarantino-punctuation *inside* the performance scene: shot goes off during the bridge, Davy Jones's pirate ghosts fight through the second verse, May finishes the song while someone goes through a window. Song completes (DI §12 R50, PI §4). Show goes on. Combat happens *inside* the concert-frame ≠ replaces it.

## Dungeon Mechanics

Cores: unaging, undying, infinite growth, **mana-generating** (mechanism → Mana entry above). Various factions claim cores — Council strip-mines them, Demon Lords contest them, the Void Cult corrupts them. Boss monsters: one/dungeon, +1 level. Unclaimed dungeons raid nearby towns. **Ava does not claim cores.** Core-claiming is a world-feature other people engage in; she is not a combatant in that economy.

## Key Worlds

**Typing:** Earth-numbered entries (Earth 519, Earth 2077, Earth 111, Earth 042, Earth 116, Earth-Prime) = **parallel worlds** — Earth variants in the multiverse, each with its own history. Non-Earth entries (Shadowoven, Hell, Faerie, Gearford) = **worlds** in their own right, not Earth variants. Use "parallel world(s)" when discussing the Earth series specifically; use "world(s)" as the generic umbrella.

Shadowoven — Grimdark fantasy. Barbello (DL posing as dark elf warlord). Active dungeons. Slavery legal.
Earth 519 — Superheroes (The Boys). Compound V. Newly awakened dungeons.
Earth 116 — Mundane Earth. Council strip-mining. Shadow government.
Earth 111 — Isolated. Kyubey-faction vs Aberrations. No multiverse knowledge. Kadath.
Hell — Lucifer's domain. Hazbin Hotel.
Faerie — Feywild. No denizen below C-Class.
Gearford — 1920s steampunk.
Earth 042 — Post-apocalyptic (Mad Max/Fallout). Strip-mined. Stardust/Daemonia's origin.
Earth 2077 — Cyberpunk noir (Cyberpunk 2077 / Shadowrun). Megacorps, cyberware, BTLs. Active dungeons. Ava's world.
Earth-Prime — DC Universe, The Endless, Constentine, Jessica Jones, Open Set.

